# Upgrade Plan: backend (20260409034008)

- **Generated**: 2026-04-09
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

## Available Tools

- JDK 21: `C:\Users\REVANTH KUMAR\.jdks\ms-21.0.10\bin` ✅
- JDK 17: `C:\Program Files\Java\jdk-17.0.3.1\bin` ✅
- Maven: **<TO_BE_INSTALLED>** (required by Step 1 for build execution)
- Version control: unavailable in workspace, changes will not be committed automatically.

## Guidelines

- Upgrade the backend Java runtime to the latest LTS target Java 21.
- Preserve existing Spring Boot 3.3.2 configuration unless a compatibility issue demands a minimal fix.
- Install Maven because no Maven executable is present on the system.
- Ensure the backend project fully compiles and all tests pass after the upgrade.

## Options

- Working branch: appmod/java-upgrade-20260409034008
- Run tests before and after the upgrade: true

## Upgrade Goals

- Upgrade Java from 17 to 21

### Technology Stack

| Technology/Dependency | Current                               | Min Compatible | Why Incompatible                                        |
| --------------------- | ------------------------------------- | -------------- | ------------------------------------------------------- |
| Java runtime          | 17                                    | 21             | User requested latest LTS runtime upgrade               |
| Spring Boot           | 3.3.2                                 | 3.3.2          | Compatible with Java 21; no upgrade needed              |
| Maven                 | none installed                        | 3.9.x          | Required to execute builds for Java 21 compilation      |
| maven-compiler-plugin | default managed by Spring Boot parent | 3.11+          | Required to support Java 21 source/target compatibility |
| maven-surefire-plugin | default managed                       | 3.1+           | Recommended for Java 21 test execution compatibility    |

### Derived Upgrades

- Install Maven 3.9.x or later because Java 21 requires Maven 3.9+ for reliable compilation.
- Keep Spring Boot 3.3.2 unchanged because it already supports Java 21 and avoids unnecessary dependency churn.

## Upgrade Steps

- Step 1: Setup Environment
  - Rationale: Install the missing build tool required to execute the upgrade and confirm the available Java runtime.
  - Changes to Make:
    - Install Maven 3.9.x using the platform tool.
    - Verify `mvn -version` with the installed Maven.
    - Verify `java -version` from the Java 21 installation path.
  - Verification:
    - Command: `mvn -version` and `java -version`
    - JDK: Java 21 path
    - Expected: Maven installed and the Java 21 runtime is accessible.

- Step 2: Setup Baseline
  - Rationale: Establish a pre-upgrade compilation and test baseline using the current Java 17 runtime and newly installed Maven.
  - Changes to Make:
    - Run baseline build with Java 17 and Maven.
    - Record whether the current project compiles and tests pass before changing `pom.xml`.
  - Verification:
    - Command: `mvn clean test -q`
    - JDK: Java 17 path
    - Expected: Baseline compilation and tests pass or documented baseline issues are captured.

- Step 3: Upgrade Java runtime to Java 21
  - Rationale: Apply the requested runtime upgrade by updating the project configuration to target Java 21.
  - Changes to Make:
    - Update `backend/pom.xml` property `<java.version>` from `17` to `21`.
    - Re-run build with Java 21.
  - Verification:
    - Command: `mvn -DskipTests clean test-compile -q`
    - JDK: Java 21 path
    - Expected: Project compiles successfully with Java 21.

- Step 4: Final Validation
  - Rationale: Confirm the upgrade is complete by running the full backend test suite on Java 21.
  - Changes to Make:
    - Run `mvn clean test` with Java 21.
    - Resolve any remaining test failures or compilation issues.
  - Verification:
    - Command: `mvn clean test -q`
    - JDK: Java 21 path
    - Expected: Full test suite passes.

## Key Challenges

- No Maven installation is currently available, which prevents building until the environment is prepared.
  - Mitigation: Install Maven 3.9.x before any compile or test runs.
- The repository is not version-controlled in this workspace, so changes cannot be auto-committed or branched.
  - Mitigation: Track file edits manually and keep the session plan/progress files updated.
- The backend is currently configured for Java 17, so the only project file change should be the `<java.version>` property.
  - Mitigation: Validate with Java 21 on a clean build and fix any compiler or test incompatibilities if they appear.
