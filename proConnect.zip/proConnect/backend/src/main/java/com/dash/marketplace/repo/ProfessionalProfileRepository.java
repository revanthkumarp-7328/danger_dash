package com.dash.marketplace.repo;

import com.dash.marketplace.domain.ProfessionalProfile;
import com.dash.marketplace.domain.VerificationStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ProfessionalProfileRepository extends JpaRepository<ProfessionalProfile, Long> {
    Optional<ProfessionalProfile> findByUserId(Long userId);

    Page<ProfessionalProfile> findByVerificationStatus(VerificationStatus status, Pageable pageable);
}
