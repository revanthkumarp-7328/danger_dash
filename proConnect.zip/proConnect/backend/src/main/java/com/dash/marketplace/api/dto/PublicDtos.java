package com.dash.marketplace.api.dto;

import java.util.List;

public class PublicDtos {

    public record ServiceCategoryDto(Long id, String name) {}

    public record ServiceTypeDto(Long id, Long categoryId, String name) {}

    public record ProfessionalServiceCardDto(
            Long professionalServiceId,
            Long professionalProfileId,
            Long serviceTypeId,
            String serviceTypeName,
            String title,
            String description,
            double basePrice,
            String priceUnit,
            String professionalName,
            String city,
            double avgRating,
            int totalReviews
    ) {}

    public record ProfessionalProfileDto(
            Long profileId,
            Long userId,
            String fullName,
            String headline,
            String bio,
            String city,
            String area,
            Integer yearsExperience,
            double avgRating,
            int totalReviews,
            List<ProfessionalServiceCardDto> services,
            List<ReviewDto> reviews
    ) {}

    public record ReviewDto(
            Long id,
            Long bookingId,
            int rating,
            String comment,
            String createdAt
    ) {}
}
