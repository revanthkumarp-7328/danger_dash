package com.dash.marketplace.domain;

public enum TicketPriority {
    LOW,
    MEDIUM,
    HIGH
}
