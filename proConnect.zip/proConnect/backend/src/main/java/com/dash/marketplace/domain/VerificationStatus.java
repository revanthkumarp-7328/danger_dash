package com.dash.marketplace.domain;

public enum VerificationStatus {
    PENDING,
    APPROVED,
    REJECTED
}
