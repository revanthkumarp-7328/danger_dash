package com.dash.marketplace.api;

import com.dash.marketplace.api.dto.PublicDtos;
import com.dash.marketplace.service.PublicService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/public")
public class PublicController {

    private final PublicService publicService;

    public PublicController(PublicService publicService) {
        this.publicService = publicService;
    }

    @GetMapping("/service-categories")
    public List<PublicDtos.ServiceCategoryDto> categories() {
        return publicService.categories();
    }

    @GetMapping("/service-types")
    public List<PublicDtos.ServiceTypeDto> types(@RequestParam Long categoryId) {
        return publicService.serviceTypes(categoryId);
    }

    @GetMapping("/search")
    public Page<PublicDtos.ProfessionalServiceCardDto> search(
            @RequestParam(required = false) Long serviceTypeId,
            @RequestParam(required = false) String city,
            @RequestParam(required = false) Double minRating,
            @RequestParam(required = false) Double priceMin,
            @RequestParam(required = false) Double priceMax,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "12") int size,
            @RequestParam(defaultValue = "basePrice") String sort
    ) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sort).ascending());
        return publicService.search(serviceTypeId, city, minRating, priceMin, priceMax, pageable);
    }

    @GetMapping("/professionals/{profileId}")
    public PublicDtos.ProfessionalProfileDto profile(@PathVariable Long profileId) {
        return publicService.profile(profileId);
    }
}
