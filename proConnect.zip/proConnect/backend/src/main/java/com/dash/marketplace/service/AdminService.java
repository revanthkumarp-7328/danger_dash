package com.dash.marketplace.service;

import com.dash.marketplace.domain.*;
import com.dash.marketplace.repo.ProfessionalProfileRepository;
import com.dash.marketplace.repo.UserRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AdminService {

    private final ProfessionalProfileRepository professionalProfileRepository;
    private final UserRepository userRepository;

    public AdminService(ProfessionalProfileRepository professionalProfileRepository, UserRepository userRepository) {
        this.professionalProfileRepository = professionalProfileRepository;
        this.userRepository = userRepository;
    }

    public Page<ProfessionalProfile> pendingProfessionals(Pageable pageable) {
        return professionalProfileRepository.findByVerificationStatus(VerificationStatus.PENDING, pageable);
    }

    @Transactional
    public ProfessionalProfile approveProfessional(Long profileId) {
        ProfessionalProfile p = professionalProfileRepository.findById(profileId)
                .orElseThrow(() -> new IllegalArgumentException("Profile not found"));
        p.setVerificationStatus(VerificationStatus.APPROVED);
        return p;
    }

    @Transactional
    public ProfessionalProfile rejectProfessional(Long profileId) {
        ProfessionalProfile p = professionalProfileRepository.findById(profileId)
                .orElseThrow(() -> new IllegalArgumentException("Profile not found"));
        p.setVerificationStatus(VerificationStatus.REJECTED);
        return p;
    }

    @Transactional
    public void suspendUser(Long userId) {
        User u = userRepository.findById(userId).orElseThrow(() -> new IllegalArgumentException("User not found"));
        u.setStatus(UserStatus.SUSPENDED);
    }
}
