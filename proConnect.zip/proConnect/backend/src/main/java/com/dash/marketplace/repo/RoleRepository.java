package com.dash.marketplace.repo;

import com.dash.marketplace.domain.Role;
import com.dash.marketplace.domain.RoleName;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface RoleRepository extends JpaRepository<Role, Long> {
    Optional<Role> findByName(RoleName name);
}
