package com.dash.marketplace.service;

import com.dash.marketplace.api.dto.ProfessionalDtos;
import com.dash.marketplace.domain.*;
import com.dash.marketplace.repo.ProfessionalProfileRepository;
import com.dash.marketplace.repo.ProfessionalServiceRepository;
import com.dash.marketplace.repo.ServiceTypeRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ProfessionalManagementService {

    private final ProfessionalProfileRepository professionalProfileRepository;
    private final ServiceTypeRepository serviceTypeRepository;
    private final ProfessionalServiceRepository professionalServiceRepository;

    public ProfessionalManagementService(ProfessionalProfileRepository professionalProfileRepository,
                                         ServiceTypeRepository serviceTypeRepository,
                                         ProfessionalServiceRepository professionalServiceRepository) {
        this.professionalProfileRepository = professionalProfileRepository;
        this.serviceTypeRepository = serviceTypeRepository;
        this.professionalServiceRepository = professionalServiceRepository;
    }

    public ProfessionalProfile requireProfileByUserId(Long userId) {
        return professionalProfileRepository.findByUserId(userId)
                .orElseThrow(() -> new IllegalArgumentException("Professional profile not found"));
    }

    @Transactional
    public ProfessionalProfile updateProfile(Long userId, ProfessionalDtos.UpdateProfileRequest req) {
        ProfessionalProfile profile = requireProfileByUserId(userId);
        profile.setHeadline(req.headline());
        profile.setBio(req.bio());
        profile.setLocationCity(req.locationCity());
        profile.setLocationArea(req.locationArea());
        profile.setYearsExperience(req.yearsExperience());
        return profile;
    }

    @Transactional
    public ProfessionalService createService(Long userId, ProfessionalDtos.CreateProfessionalServiceRequest req) {
        ProfessionalProfile profile = requireProfileByUserId(userId);
        ServiceType st = serviceTypeRepository.findById(req.serviceTypeId())
                .orElseThrow(() -> new IllegalArgumentException("Service type not found"));

        PriceUnit unit;
        try {
            unit = PriceUnit.valueOf(req.priceUnit().toUpperCase());
        } catch (Exception e) {
            throw new IllegalArgumentException("Invalid priceUnit");
        }

        ProfessionalService ps = new ProfessionalService(profile, st, req.title(), req.description(), req.basePrice(), unit);
        return professionalServiceRepository.save(ps);
    }

    @Transactional
    public ProfessionalService updateService(Long userId, Long professionalServiceId, ProfessionalDtos.UpdateProfessionalServiceRequest req) {
        ProfessionalProfile profile = requireProfileByUserId(userId);
        ProfessionalService ps = professionalServiceRepository.findById(professionalServiceId)
                .orElseThrow(() -> new IllegalArgumentException("Service not found"));

        if (!ps.getProfile().getId().equals(profile.getId())) {
            throw new IllegalArgumentException("Not your service");
        }

        if (req.title() != null) ps.setTitle(req.title());
        if (req.description() != null) ps.setDescription(req.description());
        if (req.basePrice() != null) ps.setBasePrice(req.basePrice());
        if (req.priceUnit() != null) {
            try {
                ps.setPriceUnit(PriceUnit.valueOf(req.priceUnit().toUpperCase()));
            } catch (Exception e) {
                throw new IllegalArgumentException("Invalid priceUnit");
            }
        }
        if (req.active() != null) ps.setActive(req.active());

        return ps;
    }

    public List<ProfessionalService> myServices(Long userId) {
        ProfessionalProfile profile = requireProfileByUserId(userId);
        return professionalServiceRepository.findByProfileId(profile.getId());
    }
}
