package com.dash.marketplace.api;

import com.dash.marketplace.api.dto.BookingDtos;
import com.dash.marketplace.api.dto.ReviewDtos;
import com.dash.marketplace.service.BookingService;
import com.dash.marketplace.service.CurrentUserService;
import com.dash.marketplace.service.ReviewService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/user")
public class UserController {

    private final CurrentUserService currentUserService;
    private final BookingService bookingService;
    private final ReviewService reviewService;

    public UserController(CurrentUserService currentUserService,
                          BookingService bookingService,
                          ReviewService reviewService) {
        this.currentUserService = currentUserService;
        this.bookingService = bookingService;
        this.reviewService = reviewService;
    }

    @PostMapping("/bookings")
    public BookingDtos.BookingDto createBooking(@Valid @RequestBody BookingDtos.CreateBookingRequest req) {
        Long userId = currentUserService.requireUserId();
        return bookingService.createBooking(userId, req);
    }

    @GetMapping("/bookings")
    public Page<BookingDtos.BookingDto> myBookings(@RequestParam(defaultValue = "0") int page,
                                                   @RequestParam(defaultValue = "10") int size) {
        Long userId = currentUserService.requireUserId();
        return bookingService.myBookingsAsClient(userId, PageRequest.of(page, size));
    }

    @PostMapping("/bookings/{bookingId}/cancel")
    public BookingDtos.BookingDto cancel(@PathVariable Long bookingId) {
        Long userId = currentUserService.requireUserId();
        return bookingService.cancelAsClient(userId, bookingId);
    }

    @PostMapping("/reviews")
    public void createReview(@Valid @RequestBody ReviewDtos.CreateReviewRequest req) {
        Long userId = currentUserService.requireUserId();
        reviewService.createReview(userId, req);
    }
}
