package com.dash.marketplace.domain;

public enum PriceUnit {
    HOUR,
    JOB
}
