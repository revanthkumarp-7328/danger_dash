package com.dash.marketplace.service;

import com.dash.marketplace.domain.*;
import com.dash.marketplace.repo.SupportTicketRepository;
import com.dash.marketplace.repo.TicketCommentRepository;
import com.dash.marketplace.repo.UserRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class SupportService {

    private final SupportTicketRepository supportTicketRepository;
    private final TicketCommentRepository ticketCommentRepository;
    private final UserRepository userRepository;

    public SupportService(SupportTicketRepository supportTicketRepository,
                          TicketCommentRepository ticketCommentRepository,
                          UserRepository userRepository) {
        this.supportTicketRepository = supportTicketRepository;
        this.ticketCommentRepository = ticketCommentRepository;
        this.userRepository = userRepository;
    }

    @Transactional
    public SupportTicket createTicket(Long userId, String subject, String description, TicketPriority priority) {
        User user = userRepository.findById(userId).orElseThrow();
        SupportTicket t = new SupportTicket(user, subject, description, priority);
        return supportTicketRepository.save(t);
    }

    public Page<SupportTicket> myTickets(Long userId, Pageable pageable) {
        return supportTicketRepository.findByCreatedById(userId, pageable);
    }

    public List<TicketComment> ticketComments(Long ticketId, Long userId, boolean asSupport) {
        SupportTicket t = supportTicketRepository.findById(ticketId).orElseThrow(() -> new IllegalArgumentException("Ticket not found"));
        if (!asSupport && !t.getCreatedBy().getId().equals(userId)) {
            throw new IllegalArgumentException("Not your ticket");
        }
        return ticketCommentRepository.findByTicketIdOrderByCreatedAtAsc(ticketId);
    }

    @Transactional
    public TicketComment addComment(Long ticketId, Long authorUserId, String body, boolean asSupport) {
        SupportTicket t = supportTicketRepository.findById(ticketId).orElseThrow(() -> new IllegalArgumentException("Ticket not found"));
        if (!asSupport && !t.getCreatedBy().getId().equals(authorUserId)) {
            throw new IllegalArgumentException("Not your ticket");
        }
        User author = userRepository.findById(authorUserId).orElseThrow();
        TicketComment c = new TicketComment(t, author, body);
        return ticketCommentRepository.save(c);
    }

    public Page<SupportTicket> agentQueue(TicketStatus status, Pageable pageable) {
        return supportTicketRepository.findByStatus(status, pageable);
    }

    @Transactional
    public SupportTicket assignToMe(Long ticketId, Long supportUserId) {
        SupportTicket t = supportTicketRepository.findById(ticketId).orElseThrow(() -> new IllegalArgumentException("Ticket not found"));
        User support = userRepository.findById(supportUserId).orElseThrow();
        t.setAssignedTo(support);
        t.setStatus(TicketStatus.IN_PROGRESS);
        return t;
    }

    @Transactional
    public SupportTicket updateStatus(Long ticketId, TicketStatus status) {
        SupportTicket t = supportTicketRepository.findById(ticketId).orElseThrow(() -> new IllegalArgumentException("Ticket not found"));
        t.setStatus(status);
        return t;
    }
}
