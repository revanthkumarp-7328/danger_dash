package com.dash.marketplace.domain;

public enum UserStatus {
    ACTIVE,
    SUSPENDED
}
