package com.dash.marketplace.repo;

import com.dash.marketplace.domain.SupportTicket;
import com.dash.marketplace.domain.TicketStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SupportTicketRepository extends JpaRepository<SupportTicket, Long> {
    Page<SupportTicket> findByCreatedById(Long createdById, Pageable pageable);

    Page<SupportTicket> findByStatus(TicketStatus status, Pageable pageable);
}
