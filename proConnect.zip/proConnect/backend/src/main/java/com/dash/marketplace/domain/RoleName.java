package com.dash.marketplace.domain;

public enum RoleName {
    ADMIN,
    PROFESSIONAL,
    USER,
    SUPPORT
}
