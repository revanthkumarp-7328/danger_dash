package com.dash.marketplace.repo;

import com.dash.marketplace.domain.Review;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ReviewRepository extends JpaRepository<Review, Long> {
    List<Review> findByProfessionalIdOrderByCreatedAtDesc(Long professionalId);

    boolean existsByBookingId(Long bookingId);
}
