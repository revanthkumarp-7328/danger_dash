package com.dash.marketplace.api;

import com.dash.marketplace.domain.ProfessionalProfile;
import com.dash.marketplace.service.AdminService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    private final AdminService adminService;

    public AdminController(AdminService adminService) {
        this.adminService = adminService;
    }

    @GetMapping("/professionals/pending")
    public Page<ProfessionalProfile> pending(@RequestParam(defaultValue = "0") int page,
                                            @RequestParam(defaultValue = "10") int size) {
        return adminService.pendingProfessionals(PageRequest.of(page, size));
    }

    @PostMapping("/professionals/{profileId}/approve")
    public ProfessionalProfile approve(@PathVariable Long profileId) {
        return adminService.approveProfessional(profileId);
    }

    @PostMapping("/professionals/{profileId}/reject")
    public ProfessionalProfile reject(@PathVariable Long profileId) {
        return adminService.rejectProfessional(profileId);
    }

    @PostMapping("/users/{userId}/suspend")
    public void suspend(@PathVariable Long userId) {
        adminService.suspendUser(userId);
    }
}
