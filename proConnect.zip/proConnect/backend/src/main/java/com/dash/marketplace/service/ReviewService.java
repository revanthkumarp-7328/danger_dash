package com.dash.marketplace.service;

import com.dash.marketplace.api.dto.ReviewDtos;
import com.dash.marketplace.domain.*;
import com.dash.marketplace.repo.BookingRepository;
import com.dash.marketplace.repo.ProfessionalProfileRepository;
import com.dash.marketplace.repo.ReviewRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ReviewService {

    private final BookingRepository bookingRepository;
    private final ReviewRepository reviewRepository;
    private final ProfessionalProfileRepository professionalProfileRepository;

    public ReviewService(BookingRepository bookingRepository,
                         ReviewRepository reviewRepository,
                         ProfessionalProfileRepository professionalProfileRepository) {
        this.bookingRepository = bookingRepository;
        this.reviewRepository = reviewRepository;
        this.professionalProfileRepository = professionalProfileRepository;
    }

    @Transactional
    public void createReview(Long clientUserId, ReviewDtos.CreateReviewRequest req) {
        Booking booking = bookingRepository.findById(req.bookingId())
                .orElseThrow(() -> new IllegalArgumentException("Booking not found"));

        if (!booking.getClient().getId().equals(clientUserId)) {
            throw new IllegalArgumentException("Not your booking");
        }
        if (booking.getStatus() != BookingStatus.COMPLETED) {
            throw new IllegalArgumentException("Can only review completed bookings");
        }

        if (reviewRepository.existsByBookingId(booking.getId())) {
            throw new IllegalArgumentException("Already reviewed");
        }

        Review review = new Review(booking, booking.getClient(), booking.getProfessional(), req.rating(), req.comment());
        reviewRepository.save(review);

        ProfessionalProfile profile = professionalProfileRepository.findById(booking.getProfessional().getId()).orElseThrow();
        int newTotal = profile.getTotalReviews() + 1;
        double newAvg = ((profile.getAvgRating() * profile.getTotalReviews()) + req.rating()) / newTotal;
        profile.setTotalReviews(newTotal);
        profile.setAvgRating(Math.round(newAvg * 10.0) / 10.0);
    }
}
