package com.dash.marketplace.api.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class SupportDtos {

    public record CreateTicketRequest(
            @NotBlank String subject,
            @NotBlank String description,
            @NotBlank String priority
    ) {}

    public record AddCommentRequest(
            @NotBlank String body
    ) {}

    public record UpdateTicketStatusRequest(
            @NotNull String status
    ) {}
}
