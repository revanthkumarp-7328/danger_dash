package com.dash.marketplace.api.dto;

import jakarta.validation.constraints.NotNull;

import java.time.LocalDateTime;

public class BookingDtos {

    public record CreateBookingRequest(
            @NotNull Long professionalServiceId,
            LocalDateTime scheduledAt,
            String address
    ) {}

    public record BookingDto(
            Long id,
            Long clientUserId,
            String clientName,
            Long professionalProfileId,
            String professionalName,
            Long professionalServiceId,
            String serviceTitle,
            double agreedPrice,
            String status,
            LocalDateTime scheduledAt,
            String address,
            String createdAt,
            String updatedAt
    ) {}
}
