package com.dash.marketplace.repo;

import com.dash.marketplace.domain.Booking;
import com.dash.marketplace.domain.BookingStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookingRepository extends JpaRepository<Booking, Long> {
    Page<Booking> findByClientId(Long clientId, Pageable pageable);

    Page<Booking> findByProfessionalId(Long professionalId, Pageable pageable);

    Page<Booking> findByProfessionalIdAndStatus(Long professionalId, BookingStatus status, Pageable pageable);
}
