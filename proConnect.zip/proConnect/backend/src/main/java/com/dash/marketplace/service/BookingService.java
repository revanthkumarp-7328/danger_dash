package com.dash.marketplace.service;

import com.dash.marketplace.api.dto.BookingDtos;
import com.dash.marketplace.domain.*;
import com.dash.marketplace.repo.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZoneId;

@Service
public class BookingService {

    private final BookingRepository bookingRepository;
    private final UserRepository userRepository;
    private final ProfessionalServiceRepository professionalServiceRepository;
    private final ProfessionalProfileRepository professionalProfileRepository;

    public BookingService(BookingRepository bookingRepository,
                          UserRepository userRepository,
                          ProfessionalServiceRepository professionalServiceRepository,
                          ProfessionalProfileRepository professionalProfileRepository) {
        this.bookingRepository = bookingRepository;
        this.userRepository = userRepository;
        this.professionalServiceRepository = professionalServiceRepository;
        this.professionalProfileRepository = professionalProfileRepository;
    }

    @Transactional
    public BookingDtos.BookingDto createBooking(Long clientUserId, BookingDtos.CreateBookingRequest req) {
        User client = userRepository.findById(clientUserId).orElseThrow();
        ProfessionalService ps = professionalServiceRepository.findById(req.professionalServiceId())
                .orElseThrow(() -> new IllegalArgumentException("Professional service not found"));

        ProfessionalProfile pro = ps.getProfile();
        if (pro.getVerificationStatus() != VerificationStatus.APPROVED) {
            throw new IllegalArgumentException("Professional is not approved yet");
        }
        if (!ps.isActive()) {
            throw new IllegalArgumentException("Service is not active");
        }

        Booking booking = new Booking(client, pro, ps, req.scheduledAt(), req.address(), ps.getBasePrice());
        booking = bookingRepository.save(booking);
        return toDto(booking);
    }

    public Page<BookingDtos.BookingDto> myBookingsAsClient(Long clientUserId, Pageable pageable) {
        return bookingRepository.findByClientId(clientUserId, pageable).map(this::toDto);
    }

    public Page<BookingDtos.BookingDto> myBookingsAsProfessional(Long professionalProfileId, BookingStatus status, Pageable pageable) {
        if (status == null) {
            return bookingRepository.findByProfessionalId(professionalProfileId, pageable).map(this::toDto);
        }
        return bookingRepository.findByProfessionalIdAndStatus(professionalProfileId, status, pageable).map(this::toDto);
    }

    @Transactional
    public BookingDtos.BookingDto cancelAsClient(Long clientUserId, Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId).orElseThrow();
        if (!booking.getClient().getId().equals(clientUserId)) {
            throw new IllegalArgumentException("Not your booking");
        }
        if (booking.getStatus() == BookingStatus.COMPLETED) {
            throw new IllegalArgumentException("Cannot cancel completed booking");
        }
        booking.setStatus(BookingStatus.CANCELLED);
        return toDto(booking);
    }

    @Transactional
    public BookingDtos.BookingDto accept(Long professionalUserId, Long bookingId) {
        Booking booking = requireOwnedByProfessionalUser(professionalUserId, bookingId);
        if (booking.getStatus() != BookingStatus.PENDING) {
            throw new IllegalArgumentException("Booking not pending");
        }
        booking.setStatus(BookingStatus.ACCEPTED);
        return toDto(booking);
    }

    @Transactional
    public BookingDtos.BookingDto reject(Long professionalUserId, Long bookingId) {
        Booking booking = requireOwnedByProfessionalUser(professionalUserId, bookingId);
        if (booking.getStatus() != BookingStatus.PENDING) {
            throw new IllegalArgumentException("Booking not pending");
        }
        booking.setStatus(BookingStatus.REJECTED);
        return toDto(booking);
    }

    @Transactional
    public BookingDtos.BookingDto start(Long professionalUserId, Long bookingId) {
        Booking booking = requireOwnedByProfessionalUser(professionalUserId, bookingId);
        if (booking.getStatus() != BookingStatus.ACCEPTED) {
            throw new IllegalArgumentException("Booking not accepted");
        }
        booking.setStatus(BookingStatus.IN_PROGRESS);
        return toDto(booking);
    }

    @Transactional
    public BookingDtos.BookingDto complete(Long professionalUserId, Long bookingId) {
        Booking booking = requireOwnedByProfessionalUser(professionalUserId, bookingId);
        if (booking.getStatus() != BookingStatus.IN_PROGRESS) {
            throw new IllegalArgumentException("Booking not in progress");
        }
        booking.setStatus(BookingStatus.COMPLETED);
        return toDto(booking);
    }

    private Booking requireOwnedByProfessionalUser(Long professionalUserId, Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId).orElseThrow();
        ProfessionalProfile profile = professionalProfileRepository.findByUserId(professionalUserId)
                .orElseThrow(() -> new IllegalArgumentException("Professional profile not found"));

        if (!booking.getProfessional().getId().equals(profile.getId())) {
            throw new IllegalArgumentException("Not your booking");
        }
        return booking;
    }

    private BookingDtos.BookingDto toDto(Booking b) {
        return new BookingDtos.BookingDto(
                b.getId(),
                b.getClient().getId(),
                b.getClient().getFullName(),
                b.getProfessional().getId(),
                b.getProfessional().getUser().getFullName(),
                b.getProfessionalService().getId(),
                b.getProfessionalService().getTitle(),
                b.getAgreedPrice(),
                b.getStatus().name(),
                b.getScheduledAt(),
                b.getAddress(),
                b.getCreatedAt().atZone(ZoneId.systemDefault()).toOffsetDateTime().toString(),
                b.getUpdatedAt().atZone(ZoneId.systemDefault()).toOffsetDateTime().toString()
        );
    }
}
