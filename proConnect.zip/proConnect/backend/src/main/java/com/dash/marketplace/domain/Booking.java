package com.dash.marketplace.domain;

import jakarta.persistence.*;

import java.time.Instant;
import java.time.LocalDateTime;

@Entity
@Table(name = "bookings")
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "client_user_id", nullable = false)
    private User client;

    @ManyToOne(optional = false)
    @JoinColumn(name = "professional_profile_id", nullable = false)
    private ProfessionalProfile professional;

    @ManyToOne(optional = false)
    @JoinColumn(name = "professional_service_id", nullable = false)
    private ProfessionalService professionalService;

    @Column
    private LocalDateTime scheduledAt;

    @Column
    private String address;

    @Column(nullable = false)
    private double agreedPrice;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 16)
    private BookingStatus status = BookingStatus.PENDING;

    @Column(nullable = false, updatable = false)
    private Instant createdAt = Instant.now();

    @Column(nullable = false)
    private Instant updatedAt = Instant.now();

    protected Booking() {}

    public Booking(User client, ProfessionalProfile professional, ProfessionalService professionalService, LocalDateTime scheduledAt, String address, double agreedPrice) {
        this.client = client;
        this.professional = professional;
        this.professionalService = professionalService;
        this.scheduledAt = scheduledAt;
        this.address = address;
        this.agreedPrice = agreedPrice;
    }

    @PreUpdate
    public void preUpdate() {
        this.updatedAt = Instant.now();
    }

    public Long getId() {
        return id;
    }

    public User getClient() {
        return client;
    }

    public ProfessionalProfile getProfessional() {
        return professional;
    }

    public ProfessionalService getProfessionalService() {
        return professionalService;
    }

    public LocalDateTime getScheduledAt() {
        return scheduledAt;
    }

    public void setScheduledAt(LocalDateTime scheduledAt) {
        this.scheduledAt = scheduledAt;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public double getAgreedPrice() {
        return agreedPrice;
    }

    public void setAgreedPrice(double agreedPrice) {
        this.agreedPrice = agreedPrice;
    }

    public BookingStatus getStatus() {
        return status;
    }

    public void setStatus(BookingStatus status) {
        this.status = status;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }
}
