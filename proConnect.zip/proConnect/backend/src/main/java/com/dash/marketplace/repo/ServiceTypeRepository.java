package com.dash.marketplace.repo;

import com.dash.marketplace.domain.ServiceType;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ServiceTypeRepository extends JpaRepository<ServiceType, Long> {
    List<ServiceType> findByCategoryId(Long categoryId);
}
