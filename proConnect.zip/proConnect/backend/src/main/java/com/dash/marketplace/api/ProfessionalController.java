package com.dash.marketplace.api;

import com.dash.marketplace.api.dto.BookingDtos;
import com.dash.marketplace.api.dto.ProfessionalDtos;
import com.dash.marketplace.domain.BookingStatus;
import com.dash.marketplace.domain.ProfessionalProfile;
import com.dash.marketplace.domain.ProfessionalService;
import com.dash.marketplace.service.BookingService;
import com.dash.marketplace.service.CurrentUserService;
import com.dash.marketplace.service.ProfessionalManagementService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/professional")
@PreAuthorize("hasRole('PROFESSIONAL')")
public class ProfessionalController {

    private final CurrentUserService currentUserService;
    private final ProfessionalManagementService professionalManagementService;
    private final BookingService bookingService;

    public ProfessionalController(CurrentUserService currentUserService,
                                  ProfessionalManagementService professionalManagementService,
                                  BookingService bookingService) {
        this.currentUserService = currentUserService;
        this.professionalManagementService = professionalManagementService;
        this.bookingService = bookingService;
    }

    @GetMapping("/profile")
    public ProfessionalProfile myProfile() {
        Long userId = currentUserService.requireUserId();
        return professionalManagementService.requireProfileByUserId(userId);
    }

    @PutMapping("/profile")
    public ProfessionalProfile updateProfile(@Valid @RequestBody ProfessionalDtos.UpdateProfileRequest req) {
        Long userId = currentUserService.requireUserId();
        return professionalManagementService.updateProfile(userId, req);
    }

    @GetMapping("/services")
    public List<ProfessionalService> myServices() {
        Long userId = currentUserService.requireUserId();
        return professionalManagementService.myServices(userId);
    }

    @PostMapping("/services")
    public ProfessionalService createService(@Valid @RequestBody ProfessionalDtos.CreateProfessionalServiceRequest req) {
        Long userId = currentUserService.requireUserId();
        return professionalManagementService.createService(userId, req);
    }

    @PutMapping("/services/{professionalServiceId}")
    public ProfessionalService updateService(@PathVariable Long professionalServiceId,
                                             @RequestBody ProfessionalDtos.UpdateProfessionalServiceRequest req) {
        Long userId = currentUserService.requireUserId();
        return professionalManagementService.updateService(userId, professionalServiceId, req);
    }

    @GetMapping("/bookings")
    public Page<BookingDtos.BookingDto> myBookings(@RequestParam(required = false) String status,
                                                   @RequestParam(defaultValue = "0") int page,
                                                   @RequestParam(defaultValue = "10") int size) {
        Long userId = currentUserService.requireUserId();
        var profile = professionalManagementService.requireProfileByUserId(userId);

        BookingStatus st = null;
        if (status != null) {
            st = BookingStatus.valueOf(status.toUpperCase());
        }

        return bookingService.myBookingsAsProfessional(profile.getId(), st, PageRequest.of(page, size));
    }

    @PostMapping("/bookings/{bookingId}/accept")
    public BookingDtos.BookingDto accept(@PathVariable Long bookingId) {
        Long userId = currentUserService.requireUserId();
        return bookingService.accept(userId, bookingId);
    }

    @PostMapping("/bookings/{bookingId}/reject")
    public BookingDtos.BookingDto reject(@PathVariable Long bookingId) {
        Long userId = currentUserService.requireUserId();
        return bookingService.reject(userId, bookingId);
    }

    @PostMapping("/bookings/{bookingId}/start")
    public BookingDtos.BookingDto start(@PathVariable Long bookingId) {
        Long userId = currentUserService.requireUserId();
        return bookingService.start(userId, bookingId);
    }

    @PostMapping("/bookings/{bookingId}/complete")
    public BookingDtos.BookingDto complete(@PathVariable Long bookingId) {
        Long userId = currentUserService.requireUserId();
        return bookingService.complete(userId, bookingId);
    }
}
