package com.dash.marketplace.config;

import com.dash.marketplace.domain.*;
import com.dash.marketplace.repo.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class DataInitializer implements CommandLineRunner {

    private final RoleRepository roleRepository;
    private final UserRepository userRepository;
    private final ProfessionalProfileRepository professionalProfileRepository;
    private final ServiceCategoryRepository serviceCategoryRepository;
    private final ServiceTypeRepository serviceTypeRepository;
    private final ProfessionalServiceRepository professionalServiceRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(RoleRepository roleRepository,
                           UserRepository userRepository,
                           ProfessionalProfileRepository professionalProfileRepository,
                           ServiceCategoryRepository serviceCategoryRepository,
                           ServiceTypeRepository serviceTypeRepository,
                           ProfessionalServiceRepository professionalServiceRepository,
                           PasswordEncoder passwordEncoder) {
        this.roleRepository = roleRepository;
        this.userRepository = userRepository;
        this.professionalProfileRepository = professionalProfileRepository;
        this.serviceCategoryRepository = serviceCategoryRepository;
        this.serviceTypeRepository = serviceTypeRepository;
        this.professionalServiceRepository = professionalServiceRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    @Transactional
    public void run(String... args) {
        ensureRole(RoleName.ADMIN);
        ensureRole(RoleName.SUPPORT);
        ensureRole(RoleName.PROFESSIONAL);
        ensureRole(RoleName.USER);

        ServiceCategory home = ensureCategory("Home Services");
        ServiceCategory tech = ensureCategory("IT Services");

        ServiceCategory auto = ensureCategory("Automotive Services");
        ServiceCategory design = ensureCategory("Design & Creative");

        ServiceType plumber = ensureType(home, "Plumber");
        ServiceType electrician = ensureType(home, "Electrician");
        ServiceType houseCleaning = ensureType(home, "House Cleaning");
        ServiceType acRepair = ensureType(home, "AC Repair");
        ServiceType webDev = ensureType(tech, "Web Developer");
        ServiceType mobileRepair = ensureType(tech, "Mobile Repair");
        ServiceType carWash = ensureType(auto, "Car Wash");
        ServiceType graphicDesign = ensureType(design, "Graphic Designer");

        User admin = ensureUser("Admin", "admin@dash.com", "9999999999", "admin123", RoleName.ADMIN);
        User support = ensureUser("Support", "support@dash.com", "8888888888", "support123", RoleName.SUPPORT);
        User client = ensureUser("Client User", "user@dash.com", "7777777777", "user123", RoleName.USER);

        User proUser = ensureUser("Demo Professional", "pro@dash.com", "6666666666", "pro123", RoleName.PROFESSIONAL);

        ProfessionalProfile profile = ensureProfessionalProfile(
                proUser,
                "Hyderabad",
                "Gachibowli",
                "Trusted professional with quick response",
                "I provide reliable service and transparent pricing.",
                5
        );
        ensureDemoServices(profile,
                new ProfessionalService(profile, plumber,
                        "Plumbing repair", "Leak fixing, tap replacement, pipe repair", 499, PriceUnit.JOB),
                new ProfessionalService(profile, electrician,
                        "Electrical fixes", "Switchboard repair, wiring check", 399, PriceUnit.JOB),
                new ProfessionalService(profile, webDev,
                        "Website development", "React + Spring Boot web apps", 799, PriceUnit.HOUR)
        );

        User pro2 = ensureUser("Ayesha Khan", "ayesha.pro@dash.com", "9000000001", "pro123", RoleName.PROFESSIONAL);
        ProfessionalProfile profile2 = ensureProfessionalProfile(
                pro2,
                "Hyderabad",
                "Kukatpally",
                "Neat, fast and affordable home cleaning",
                "Deep cleaning, kitchen & bathroom cleaning with professional-grade products.",
                4
        );
        ensureDemoServices(profile2,
                new ProfessionalService(profile2, houseCleaning,
                        "Deep House Cleaning", "Full home deep clean with eco-friendly chemicals", 899, PriceUnit.JOB),
                new ProfessionalService(profile2, acRepair,
                        "AC Service & Gas Check", "AC cleaning, filter service, basic gas inspection", 599, PriceUnit.JOB)
        );

        User pro3 = ensureUser("Rohit Verma", "rohit.tech@dash.com", "9000000002", "pro123", RoleName.PROFESSIONAL);
        ProfessionalProfile profile3 = ensureProfessionalProfile(
                pro3,
                "Bengaluru",
                "HSR Layout",
                "Mobile repair with same-day delivery",
                "Screen replacement, battery issues, charging port repair. Transparent pricing.",
                6
        );
        ensureDemoServices(profile3,
                new ProfessionalService(profile3, mobileRepair,
                        "Phone Screen Replacement", "Premium quality screen replacement (Android/iPhone)", 1499, PriceUnit.JOB),
                new ProfessionalService(profile3, webDev,
                        "Landing Page Setup", "Modern responsive landing page + deployment", 999, PriceUnit.JOB)
        );

        User pro4 = ensureUser("Sana Studio", "sana.design@dash.com", "9000000003", "pro123", RoleName.PROFESSIONAL);
        ProfessionalProfile profile4 = ensureProfessionalProfile(
                pro4,
                "Chennai",
                "Velachery",
                "Branding, logos and social media creatives",
                "Logo design, brand kit, posters and Instagram creatives.",
                7
        );
        ensureDemoServices(profile4,
                new ProfessionalService(profile4, graphicDesign,
                        "Logo & Brand Kit", "3 logo concepts + color palette + typography", 1999, PriceUnit.JOB),
                new ProfessionalService(profile4, graphicDesign,
                        "Social Media Creatives", "10 custom posts (editable source included)", 999, PriceUnit.JOB)
        );

        User pro5 = ensureUser("Kiran AutoCare", "kiran.auto@dash.com", "9000000004", "pro123", RoleName.PROFESSIONAL);
        ProfessionalProfile profile5 = ensureProfessionalProfile(
                pro5,
                "Pune",
                "Wakad",
                "Doorstep car wash and detailing",
                "Foam wash, interior vacuum, dashboard polish. Doorstep service.",
                3
        );
        ensureDemoServices(profile5,
                new ProfessionalService(profile5, carWash,
                        "Doorstep Car Wash", "Foam wash + interior vacuum + tyre polish", 499, PriceUnit.JOB),
                new ProfessionalService(profile5, carWash,
                        "Car Detailing", "Interior + exterior detailing with premium products", 1499, PriceUnit.JOB)
        );
    }

    private ProfessionalProfile ensureProfessionalProfile(User proUser,
                                                         String city,
                                                         String area,
                                                         String headline,
                                                         String bio,
                                                         Integer years) {
        ProfessionalProfile profile = professionalProfileRepository.findByUserId(proUser.getId())
                .orElseGet(() -> professionalProfileRepository.save(new ProfessionalProfile(proUser)));

        if (profile.getVerificationStatus() == VerificationStatus.PENDING) {
            profile.setVerificationStatus(VerificationStatus.APPROVED);
        }
        if (profile.getLocationCity() == null) profile.setLocationCity(city);
        if (profile.getLocationArea() == null) profile.setLocationArea(area);
        if (profile.getHeadline() == null) profile.setHeadline(headline);
        if (profile.getBio() == null) profile.setBio(bio);
        if (profile.getYearsExperience() == null) profile.setYearsExperience(years);
        return profile;
    }

    private void ensureDemoServices(ProfessionalProfile profile, ProfessionalService... services) {
        if (!professionalServiceRepository.findByProfileId(profile.getId()).isEmpty()) {
            return;
        }
        for (ProfessionalService s : services) {
            professionalServiceRepository.save(s);
        }
    }

    private void ensureRole(RoleName name) {
        roleRepository.findByName(name).orElseGet(() -> roleRepository.save(new Role(name)));
    }

    private User ensureUser(String fullName, String email, String phone, String rawPassword, RoleName roleName) {
        return userRepository.findByEmail(email).orElseGet(() -> {
            User u = new User(fullName, email, phone, passwordEncoder.encode(rawPassword));
            u.getRoles().add(roleRepository.findByName(roleName).orElseThrow());
            return userRepository.save(u);
        });
    }

    private ServiceCategory ensureCategory(String name) {
        return serviceCategoryRepository.findByNameIgnoreCase(name)
                .orElseGet(() -> serviceCategoryRepository.save(new ServiceCategory(name)));
    }

    private ServiceType ensureType(ServiceCategory category, String name) {
        return serviceTypeRepository.findAll().stream()
                .filter(t -> t.getCategory().getId().equals(category.getId()) && t.getName().equalsIgnoreCase(name))
                .findFirst()
                .orElseGet(() -> serviceTypeRepository.save(new ServiceType(category, name)));
    }
}
