package com.dash.marketplace.api.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class ProfessionalDtos {

    public record UpdateProfileRequest(
            String headline,
            String bio,
            String locationCity,
            String locationArea,
            Integer yearsExperience
    ) {}

    public record CreateProfessionalServiceRequest(
            @NotNull Long serviceTypeId,
            @NotBlank String title,
            String description,
            @NotNull Double basePrice,
            @NotBlank String priceUnit
    ) {}

    public record UpdateProfessionalServiceRequest(
            String title,
            String description,
            Double basePrice,
            String priceUnit,
            Boolean active
    ) {}
}
