package com.dash.marketplace.api;

import com.dash.marketplace.api.dto.SupportDtos;
import com.dash.marketplace.domain.*;
import com.dash.marketplace.service.CurrentUserService;
import com.dash.marketplace.service.SupportService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/support")
public class SupportController {

    private final CurrentUserService currentUserService;
    private final SupportService supportService;

    public SupportController(CurrentUserService currentUserService, SupportService supportService) {
        this.currentUserService = currentUserService;
        this.supportService = supportService;
    }

    @PostMapping("/tickets")
    public SupportTicket createTicket(@Valid @RequestBody SupportDtos.CreateTicketRequest req) {
        Long userId = currentUserService.requireUserId();
        TicketPriority priority = TicketPriority.valueOf(req.priority().toUpperCase());
        return supportService.createTicket(userId, req.subject(), req.description(), priority);
    }

    @GetMapping("/tickets/mine")
    public Page<SupportTicket> myTickets(@RequestParam(defaultValue = "0") int page,
                                         @RequestParam(defaultValue = "10") int size) {
        Long userId = currentUserService.requireUserId();
        return supportService.myTickets(userId, PageRequest.of(page, size));
    }

    @GetMapping("/tickets/{ticketId}/comments")
    public List<TicketComment> comments(@PathVariable Long ticketId) {
        Long userId = currentUserService.requireUserId();
        boolean asSupport = hasSupportRole();
        return supportService.ticketComments(ticketId, userId, asSupport);
    }

    @PostMapping("/tickets/{ticketId}/comments")
    public TicketComment addComment(@PathVariable Long ticketId, @Valid @RequestBody SupportDtos.AddCommentRequest req) {
        Long userId = currentUserService.requireUserId();
        boolean asSupport = hasSupportRole();
        return supportService.addComment(ticketId, userId, req.body(), asSupport);
    }

    @GetMapping("/agent/tickets")
    @PreAuthorize("hasRole('SUPPORT') or hasRole('ADMIN')")
    public Page<SupportTicket> agentQueue(@RequestParam(defaultValue = "OPEN") String status,
                                          @RequestParam(defaultValue = "0") int page,
                                          @RequestParam(defaultValue = "10") int size) {
        TicketStatus st = TicketStatus.valueOf(status.toUpperCase());
        return supportService.agentQueue(st, PageRequest.of(page, size));
    }

    @PostMapping("/agent/tickets/{ticketId}/assign-to-me")
    @PreAuthorize("hasRole('SUPPORT') or hasRole('ADMIN')")
    public SupportTicket assignToMe(@PathVariable Long ticketId) {
        Long userId = currentUserService.requireUserId();
        return supportService.assignToMe(ticketId, userId);
    }

    @PostMapping("/agent/tickets/{ticketId}/status")
    @PreAuthorize("hasRole('SUPPORT') or hasRole('ADMIN')")
    public SupportTicket updateStatus(@PathVariable Long ticketId, @Valid @RequestBody SupportDtos.UpdateTicketStatusRequest req) {
        TicketStatus st = TicketStatus.valueOf(req.status().toUpperCase());
        return supportService.updateStatus(ticketId, st);
    }

    private boolean hasSupportRole() {
        var auth = org.springframework.security.core.context.SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) return false;
        return auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_SUPPORT") || a.getAuthority().equals("ROLE_ADMIN"));
    }
}
