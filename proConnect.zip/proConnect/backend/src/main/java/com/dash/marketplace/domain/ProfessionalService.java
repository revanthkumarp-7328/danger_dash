package com.dash.marketplace.domain;

import jakarta.persistence.*;

@Entity
@Table(name = "professional_services")
public class ProfessionalService {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "profile_id", nullable = false)
    private ProfessionalProfile profile;

    @ManyToOne(optional = false)
    @JoinColumn(name = "service_type_id", nullable = false)
    private ServiceType serviceType;

    @Column(nullable = false)
    private String title;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(nullable = false)
    private double basePrice;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 8)
    private PriceUnit priceUnit = PriceUnit.JOB;

    @Column(nullable = false)
    private boolean active = true;

    protected ProfessionalService() {}

    public ProfessionalService(ProfessionalProfile profile, ServiceType serviceType, String title, String description, double basePrice, PriceUnit priceUnit) {
        this.profile = profile;
        this.serviceType = serviceType;
        this.title = title;
        this.description = description;
        this.basePrice = basePrice;
        this.priceUnit = priceUnit;
    }

    public Long getId() {
        return id;
    }

    public ProfessionalProfile getProfile() {
        return profile;
    }

    public ServiceType getServiceType() {
        return serviceType;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getBasePrice() {
        return basePrice;
    }

    public void setBasePrice(double basePrice) {
        this.basePrice = basePrice;
    }

    public PriceUnit getPriceUnit() {
        return priceUnit;
    }

    public void setPriceUnit(PriceUnit priceUnit) {
        this.priceUnit = priceUnit;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}
