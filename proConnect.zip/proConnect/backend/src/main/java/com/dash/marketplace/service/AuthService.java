package com.dash.marketplace.service;

import com.dash.marketplace.api.dto.AuthDtos;
import com.dash.marketplace.domain.*;
import com.dash.marketplace.repo.ProfessionalProfileRepository;
import com.dash.marketplace.repo.RoleRepository;
import com.dash.marketplace.repo.UserRepository;
import com.dash.marketplace.security.JwtService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final ProfessionalProfileRepository professionalProfileRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public AuthService(UserRepository userRepository,
                       RoleRepository roleRepository,
                       ProfessionalProfileRepository professionalProfileRepository,
                       PasswordEncoder passwordEncoder,
                       JwtService jwtService) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.professionalProfileRepository = professionalProfileRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }

    @Transactional
    public AuthDtos.AuthResponse register(AuthDtos.RegisterRequest req) {
        userRepository.findByEmail(req.email()).ifPresent(u -> {
            throw new IllegalArgumentException("Email already registered");
        });

        RoleName roleName;
        try {
            roleName = RoleName.valueOf(req.role().toUpperCase());
        } catch (Exception e) {
            throw new IllegalArgumentException("Invalid role");
        }

        if (roleName == RoleName.ADMIN) {
            throw new IllegalArgumentException("Cannot self-register as ADMIN");
        }

        User user = new User(req.fullName(), req.email(), req.phone(), passwordEncoder.encode(req.password()));
        Role role = roleRepository.findByName(roleName).orElseThrow();
        user.getRoles().add(role);

        user = userRepository.save(user);

        if (roleName == RoleName.PROFESSIONAL) {
            professionalProfileRepository.save(new ProfessionalProfile(user));
        }

        List<String> roles = user.getRoles().stream().map(r -> r.getName().name()).toList();
        String token = jwtService.generateAccessToken(user.getId(), user.getEmail(), roles);

        return new AuthDtos.AuthResponse(token, user.getId(), user.getEmail(), user.getFullName(), roles);
    }

    public AuthDtos.AuthResponse login(AuthDtos.LoginRequest req) {
        User user = userRepository.findByEmail(req.email()).orElseThrow(() -> new IllegalArgumentException("Invalid credentials"));
        if (user.getStatus() != UserStatus.ACTIVE) {
            throw new IllegalArgumentException("User is suspended");
        }
        if (!passwordEncoder.matches(req.password(), user.getPasswordHash())) {
            throw new IllegalArgumentException("Invalid credentials");
        }

        List<String> roles = user.getRoles().stream().map(r -> r.getName().name()).toList();
        String token = jwtService.generateAccessToken(user.getId(), user.getEmail(), roles);

        return new AuthDtos.AuthResponse(token, user.getId(), user.getEmail(), user.getFullName(), roles);
    }
}
