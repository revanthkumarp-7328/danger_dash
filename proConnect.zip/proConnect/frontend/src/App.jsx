import React, { useState } from "react";
import { Navigate, Route, Routes, Link, useNavigate } from "react-router-dom";
import { useAuth } from "./state/AuthContext.jsx";
import LoginPage from "./pages/LoginPage.jsx";
import RegisterPage from "./pages/RegisterPage.jsx";
import HomePage from "./pages/HomePage.jsx";
import DashboardPage from "./pages/DashboardPage.jsx";

function PrivateRoute({ children }) {
  const auth = useAuth();
  if (!auth.isAuthed) return <Navigate to="/login" replace />;
  return children;
}

function TopNav() {
  const auth = useAuth();
  const navigate = useNavigate();
  const [dropdownOpen, setDropdownOpen] = useState(false);

  return (
    <nav className="navbar">
      <div className="navbar-container">
        <Link className="navbar-brand" to="/">
          <i className="fas fa-handshake"></i>
          ProConnect
        </Link>
        <div className="navbar-menu">
          <Link className="navbar-link" to="/">
            Home
          </Link>
          <Link className="navbar-link" to="/#categories">
            Categories
          </Link>
          <Link className="navbar-link" to="/#professionals">
            Professionals
          </Link>
          <Link className="navbar-link" to="/#services">
            Services
          </Link>
        </div>
        {!auth.isAuthed ? (
          <div className="navbar-auth">
            <button
              className="btn btn-outline"
              onClick={() => navigate("/login")}
            >
              Login
            </button>
            <button
              className="btn btn-primary"
              onClick={() => navigate("/register")}
            >
              Sign Up
            </button>
          </div>
        ) : (
          <div
            className="user-menu"
            onClick={() => setDropdownOpen(!dropdownOpen)}
          >
            <img
              src={`https://randomuser.me/api/portraits/men/${auth.user?.id || 1}.jpg`}
              alt="User"
              className="user-avatar"
            />
            <span>{auth.user?.name || auth.user?.email}</span>
            <i className="fas fa-chevron-down"></i>
            <div className={`user-dropdown ${dropdownOpen ? "active" : ""}`}>
              <Link
                className="user-dropdown-item"
                to="/dashboard"
                onClick={() => setDropdownOpen(false)}
              >
                <i className="fas fa-home"></i> Dashboard
              </Link>
              <button
                className="user-dropdown-item"
                onClick={() => {
                  setDropdownOpen(false);
                  auth.logout();
                  navigate("/");
                }}
                style={{
                  border: "none",
                  background: "none",
                  cursor: "pointer",
                }}
              >
                <i className="fas fa-sign-out-alt"></i> Logout
              </button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}

export default function App() {
  return (
    <>
      <TopNav />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route
          path="/dashboard/*"
          element={
            <PrivateRoute>
              <DashboardPage />
            </PrivateRoute>
          }
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </>
  );
}
