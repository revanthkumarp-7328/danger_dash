export function getToken() {
  return localStorage.getItem("token");
}

export function setToken(token) {
  if (!token) localStorage.removeItem("token");
  else localStorage.setItem("token", token);
}

export async function apiFetch(path, options = {}) {
  const apiBase = (import.meta?.env?.VITE_API_BASE_URL || "").replace(
    /\/$/,
    "",
  );
  const url = path.startsWith("/") ? `${apiBase}${path}` : `${apiBase}/${path}`;

  const headers = new Headers(options.headers || {});

  if (options.body && !headers.get("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }

  const token = getToken();
  if (token) {
    headers.set("Authorization", `Bearer ${token}`);
  }

  const res = await fetch(url, { ...options, headers });

  const contentType = res.headers.get("content-type") || "";
  const data = contentType.includes("application/json")
    ? await res.json()
    : await res.text();

  if (!res.ok) {
    const message = (() => {
      if (!data) return "Request failed";
      if (typeof data === "string") return data || "Request failed";
      if (typeof data !== "object") return "Request failed";

      // Spring Boot default error JSON: {timestamp,status,error,message,path}
      // Spring Boot ProblemDetail: {type,title,status,detail,instance}
      return (
        data.message ||
        data.detail ||
        data.error ||
        data.title ||
        "Request failed"
      );
    })();
    const err = new Error(message);
    err.status = res.status;
    err.data = data;
    throw err;
  }

  return data;
}
