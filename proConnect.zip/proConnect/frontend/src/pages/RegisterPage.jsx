import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "../state/AuthContext.jsx";

export default function RegisterPage() {
  const auth = useAuth();
  const navigate = useNavigate();

  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("user");
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await auth.register(fullName, email, password, role);
      navigate("/dashboard");
    } catch (e2) {
      setError(e2?.message || "Registration failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "100px 20px 40px",
        background: "var(--gray-100)",
      }}
    >
      <div style={{ width: "100%", maxWidth: "500px" }}>
        <div className="card">
          <div style={{ textAlign: "center", marginBottom: "24px" }}>
            <h2
              style={{
                fontSize: "24px",
                fontWeight: "700",
                marginBottom: "8px",
              }}
            >
              Create Account
            </h2>
            <p style={{ color: "var(--gray)", fontSize: "14px" }}>
              Join ProConnect and find the right professionals
            </p>
          </div>

          <form onSubmit={onSubmit}>
            <div className="form-group">
              <label className="form-label">Full Name</label>
              <input
                className="form-input"
                type="text"
                placeholder="Enter your full name"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                required
              />
            </div>
            <div className="form-group">
              <label className="form-label">Email</label>
              <input
                className="form-input"
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="form-group">
              <label className="form-label">Password</label>
              <input
                className="form-input"
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <div className="form-group">
              <label className="form-label">Account Type</label>
              <select
                className="form-select"
                value={role}
                onChange={(e) => setRole(e.target.value)}
              >
                <option value="user">User</option>
                <option value="professional">Professional</option>
                <option value="support">Support</option>
              </select>
              <small style={{ color: "var(--gray)", fontSize: "12px" }}>
                Admin accounts are created by the system.
              </small>
            </div>
            {error && (
              <div className="form-group">
                <div className="error">{error}</div>
              </div>
            )}
            <div
              className="form-group"
              style={{ display: "flex", gap: "12px" }}
            >
              <button
                className="btn btn-primary"
                disabled={loading}
                type="submit"
                style={{ flex: 1 }}
              >
                {loading ? "Creating..." : "Create Account"}
              </button>
            </div>
            <div
              style={{
                textAlign: "center",
                fontSize: "14px",
                color: "var(--gray)",
              }}
            >
              Already have an account?{" "}
              <Link
                to="/login"
                style={{ color: "var(--primary)", textDecoration: "none" }}
              >
                Sign in
              </Link>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
