import React, { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { apiFetch } from "../../api/http.js";
import { useAuth } from "../../state/AuthContext.jsx";

export default function UserBookFormPage() {
  const auth = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const params = useMemo(
    () => new URLSearchParams(location.search),
    [location.search],
  );
  const initialServiceId = params.get("serviceId") || "";

  const [professionalServiceId, setProfessionalServiceId] =
    useState(initialServiceId);
  const [scheduledAt, setScheduledAt] = useState("");
  const [address, setAddress] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (auth.user?.role !== "user") {
      navigate("/dashboard", { replace: true });
    }
  }, [auth.user?.role, navigate]);

  async function submit(e) {
    e.preventDefault();
    if (!scheduledAt) {
      alert("Please select a date and time");
      return;
    }
    setLoading(true);
    try {
      await apiFetch("/api/user/bookings", {
        method: "POST",
        body: JSON.stringify({
          professionalServiceId: Number(professionalServiceId),
          scheduledAt: new Date(scheduledAt).toISOString(),
          address,
        }),
      });
      navigate("/dashboard/bookings");
    } catch (e2) {
      alert(e2?.message || "Booking failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <div className="dashboard-header">
        <h1 className="dashboard-title">Book a Service</h1>
        <button
          className="btn btn-outline"
          onClick={() => navigate("/dashboard/bookings")}
        >
          <i className="fas fa-arrow-left"></i> Back
        </button>
      </div>

      <div className="card">
        <form onSubmit={submit}>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: "20px",
              marginBottom: "20px",
            }}
          >
            <div className="form-group" style={{ marginBottom: 0 }}>
              <label className="form-label">Professional Service ID</label>
              <input
                className="form-input"
                value={professionalServiceId}
                onChange={(e) => setProfessionalServiceId(e.target.value)}
                required
              />
              <small style={{ color: "var(--gray)", fontSize: "12px" }}>
                Tip: choose a service from Home search then click Book.
              </small>
            </div>

            <div className="form-group" style={{ marginBottom: 0 }}>
              <label className="form-label">Scheduled At</label>
              <input
                className="form-input"
                type="datetime-local"
                value={scheduledAt}
                onChange={(e) => setScheduledAt(e.target.value)}
                required
              />
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Address / Notes</label>
            <input
              className="form-input"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Apartment, street, notes..."
            />
          </div>

          <div style={{ display: "flex", gap: "12px" }}>
            <button
              className="btn btn-primary"
              type="submit"
              disabled={loading}
            >
              <i className="fas fa-check"></i>{" "}
              {loading ? "Submitting..." : "Submit Booking"}
            </button>
            <button
              className="btn btn-outline"
              type="button"
              onClick={() => navigate("/dashboard/bookings")}
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </>
  );
}
