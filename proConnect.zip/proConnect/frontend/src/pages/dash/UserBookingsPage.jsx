import React, { useEffect, useState } from "react";
import { apiFetch } from "../../api/http.js";

function badgeForStatus(status) {
  if (status === "COMPLETED") return "badge badge-success";
  if (status === "IN_PROGRESS") return "badge badge-warning";
  if (status === "CANCELLED" || status === "REJECTED")
    return "badge badge-danger";
  return "badge badge-primary";
}

export default function UserBookingsPage() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const data = await apiFetch("/api/user/bookings?page=0&size=50");
      setItems(data.content || []);
    } catch (e) {
      setError(e?.message || "Failed to load bookings");
      setItems([]);
    } finally {
      setLoading(false);
    }
  }

  async function cancel(bookingId) {
    try {
      await apiFetch(`/api/user/bookings/${bookingId}/cancel`, {
        method: "POST",
      });
      await load();
    } catch (e) {
      alert(e?.message || "Failed to cancel");
    }
  }

  useEffect(() => {
    load();
  }, []);

  return (
    <>
      <div className="dashboard-header">
        <h1 className="dashboard-title">My Bookings</h1>
        <button className="btn btn-outline" onClick={load} disabled={loading}>
          <i className="fas fa-sync-alt"></i> Refresh
        </button>
      </div>

      <div className="table-container">
        {error && (
          <div className="error" style={{ padding: "20px" }}>
            {error}
          </div>
        )}

        {loading ? (
          <div className="loading">Loading bookings...</div>
        ) : items.length === 0 ? (
          <div className="empty">
            No bookings yet. <a href="/">Find a professional</a>
          </div>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Service</th>
                <th>Professional</th>
                <th>Date</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {items.map((b) => (
                <tr key={b.id}>
                  <td>{b.serviceTypeName}</td>
                  <td>{b.professionalName}</td>
                  <td>
                    {b.scheduledAt
                      ? new Date(b.scheduledAt).toLocaleDateString()
                      : "-"}
                  </td>
                  <td>
                    <span className={badgeForStatus(b.status)}>{b.status}</span>
                  </td>
                  <td>
                    {b.status === "PENDING" ? (
                      <button
                        className="btn btn-sm btn-outline"
                        onClick={() => cancel(b.id)}
                      >
                        Cancel
                      </button>
                    ) : (
                      <span style={{ color: "var(--gray)" }}>-</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}
