import React, { useEffect, useState } from "react";
import { apiFetch } from "../../api/http.js";

function badgeForStatus(status) {
  if (status === "COMPLETED") return "badge badge-success";
  if (status === "IN_PROGRESS") return "badge badge-warning";
  if (status === "CANCELLED" || status === "REJECTED")
    return "badge badge-danger";
  return "badge badge-primary";
}

export default function ProfessionalBookingsPage() {
  const [items, setItems] = useState([]);
  const [status, setStatus] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  async function load(nextStatus = status) {
    setLoading(true);
    setError(null);
    try {
      const qs = new URLSearchParams({ page: "0", size: "50" });
      if (nextStatus) qs.set("status", nextStatus);
      const data = await apiFetch(
        `/api/professional/bookings?${qs.toString()}`,
      );
      setItems(data.content || []);
    } catch (e) {
      setError(e?.message || "Failed to load bookings");
      setItems([]);
    } finally {
      setLoading(false);
    }
  }

  async function action(bookingId, verb) {
    try {
      await apiFetch(`/api/professional/bookings/${bookingId}/${verb}`, {
        method: "POST",
      });
      await load();
    } catch (e) {
      alert(e?.message || "Failed");
    }
  }

  useEffect(() => {
    load();
  }, []);

  return (
    <>
      <div className="dashboard-header">
        <h1 className="dashboard-title">My Bookings</h1>
        <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
          <select
            className="form-select"
            value={status}
            onChange={(e) => {
              setStatus(e.target.value);
              load(e.target.value);
            }}
            style={{ width: "auto", minWidth: "150px" }}
          >
            <option value="">All</option>
            <option value="PENDING">PENDING</option>
            <option value="ACCEPTED">ACCEPTED</option>
            <option value="IN_PROGRESS">IN_PROGRESS</option>
            <option value="COMPLETED">COMPLETED</option>
            <option value="REJECTED">REJECTED</option>
            <option value="CANCELLED">CANCELLED</option>
          </select>
          <button
            className="btn btn-outline"
            onClick={() => load()}
            disabled={loading}
          >
            <i className="fas fa-sync-alt"></i> Refresh
          </button>
        </div>
      </div>

      <div className="table-container">
        {error && (
          <div className="error" style={{ padding: "20px" }}>
            {error}
          </div>
        )}

        {loading ? (
          <div className="loading">Loading bookings...</div>
        ) : items.length === 0 ? (
          <div className="empty">No bookings found</div>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Service</th>
                <th>Client</th>
                <th>Date</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {items.map((b) => (
                <tr key={b.id}>
                  <td>{b.serviceTypeName}</td>
                  <td>{b.clientName}</td>
                  <td>
                    {b.scheduledAt
                      ? new Date(b.scheduledAt).toLocaleDateString()
                      : "-"}
                  </td>
                  <td>
                    <span className={badgeForStatus(b.status)}>{b.status}</span>
                  </td>
                  <td>
                    <div
                      style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}
                    >
                      {b.status === "PENDING" && (
                        <>
                          <button
                            className="btn btn-sm btn-primary"
                            onClick={() => action(b.id, "accept")}
                          >
                            Accept
                          </button>
                          <button
                            className="btn btn-sm btn-outline"
                            onClick={() => action(b.id, "reject")}
                          >
                            Reject
                          </button>
                        </>
                      )}
                      {b.status === "ACCEPTED" && (
                        <button
                          className="btn btn-sm btn-primary"
                          onClick={() => action(b.id, "start")}
                        >
                          Start
                        </button>
                      )}
                      {b.status === "IN_PROGRESS" && (
                        <button
                          className="btn btn-sm btn-primary"
                          onClick={() => action(b.id, "complete")}
                        >
                          Complete
                        </button>
                      )}
                      {b.status !== "PENDING" &&
                        b.status !== "ACCEPTED" &&
                        b.status !== "IN_PROGRESS" && (
                          <span style={{ color: "var(--gray)" }}>-</span>
                        )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}
