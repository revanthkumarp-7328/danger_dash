import React, { useEffect, useState } from "react";
import { apiFetch } from "../../api/http.js";

function badgeForTicketStatus(status) {
  if (status === "RESOLVED" || status === "CLOSED")
    return "badge badge-success";
  if (status === "IN_PROGRESS") return "badge badge-warning";
  return "badge badge-primary";
}

function badgeForPriority(priority) {
  if (priority === "HIGH") return "badge badge-danger";
  if (priority === "LOW") return "badge badge-primary";
  return "badge badge-warning";
}

export default function SupportQueuePage() {
  const [status, setStatus] = useState("OPEN");
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  async function load(nextStatus = status) {
    setLoading(true);
    setError(null);
    try {
      const data = await apiFetch(
        `/api/support/agent/tickets?status=${encodeURIComponent(nextStatus)}&page=0&size=50`,
      );
      setItems(data.content || []);
    } catch (e) {
      setError(e?.message || "Failed to load queue");
      setItems([]);
    } finally {
      setLoading(false);
    }
  }

  async function setTicketStatus(ticketId, next) {
    try {
      await apiFetch(`/api/support/agent/tickets/${ticketId}/status`, {
        method: "POST",
        body: JSON.stringify({ status: next }),
      });
      await load();
    } catch (e) {
      alert(e?.message || "Failed to update");
    }
  }

  async function assignToMe(ticketId) {
    try {
      await apiFetch(`/api/support/agent/tickets/${ticketId}/assign-to-me`, {
        method: "POST",
      });
      await load();
    } catch (e) {
      alert(e?.message || "Failed to assign");
    }
  }

  useEffect(() => {
    load();
  }, []);

  return (
    <>
      <div className="dashboard-header">
        <h1 className="dashboard-title">Support Tickets</h1>
        <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
          <label style={{ fontSize: "14px", color: "var(--gray)" }}>
            Status
          </label>
          <select
            className="form-select"
            value={status}
            onChange={(e) => {
              setStatus(e.target.value);
              load(e.target.value);
            }}
            style={{ width: "auto", minWidth: "150px" }}
          >
            <option value="OPEN">OPEN</option>
            <option value="IN_PROGRESS">IN_PROGRESS</option>
            <option value="RESOLVED">RESOLVED</option>
            <option value="CLOSED">CLOSED</option>
          </select>
          <button
            className="btn btn-outline"
            onClick={() => load()}
            disabled={loading}
          >
            <i className="fas fa-sync-alt"></i> Refresh
          </button>
        </div>
      </div>

      <div className="table-container">
        {error && (
          <div className="error" style={{ padding: "20px" }}>
            {error}
          </div>
        )}

        {loading ? (
          <div className="loading">Loading tickets...</div>
        ) : items.length === 0 ? (
          <div className="empty">No tickets found</div>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Created By</th>
                <th>Subject</th>
                <th>Priority</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {items.map((t) => (
                <tr key={t.id}>
                  <td>#{t.id}</td>
                  <td>{t.createdBy?.fullName || t.createdBy?.email || "-"}</td>
                  <td>{t.subject}</td>
                  <td>
                    <span className={badgeForPriority(t.priority)}>
                      {t.priority}
                    </span>
                  </td>
                  <td>
                    <span className={badgeForTicketStatus(t.status)}>
                      {t.status}
                    </span>
                  </td>
                  <td>
                    <div
                      style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}
                    >
                      <button
                        className="btn btn-sm btn-outline"
                        onClick={() => assignToMe(t.id)}
                      >
                        Assign
                      </button>
                      <button
                        className="btn btn-sm btn-primary"
                        onClick={() => setTicketStatus(t.id, "IN_PROGRESS")}
                      >
                        In progress
                      </button>
                      <button
                        className="btn btn-sm btn-outline"
                        onClick={() => setTicketStatus(t.id, "RESOLVED")}
                      >
                        Resolve
                      </button>
                      <button
                        className="btn btn-sm btn-outline"
                        onClick={() => setTicketStatus(t.id, "CLOSED")}
                      >
                        Close
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}
