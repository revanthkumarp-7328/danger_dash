import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "../state/AuthContext.jsx";

export default function LoginPage() {
  const auth = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await auth.login(email, password);
      navigate("/dashboard");
    } catch (e2) {
      setError(e2?.message || "Login failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "100px 20px 40px",
        background: "var(--gray-100)",
      }}
    >
      <div style={{ width: "100%", maxWidth: "500px" }}>
        <div className="card">
          <div style={{ textAlign: "center", marginBottom: "24px" }}>
            <h2
              style={{
                fontSize: "24px",
                fontWeight: "700",
                marginBottom: "8px",
              }}
            >
              Welcome Back
            </h2>
            <p style={{ color: "var(--gray)", fontSize: "14px" }}>
              Sign in to your ProConnect account
            </p>
          </div>

          <form onSubmit={onSubmit}>
            <div className="form-group">
              <label className="form-label">Email</label>
              <input
                className="form-input"
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="form-group">
              <label className="form-label">Password</label>
              <input
                className="form-input"
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            {error && (
              <div className="form-group">
                <div className="error">{error}</div>
              </div>
            )}
            <div
              className="form-group"
              style={{ display: "flex", gap: "12px" }}
            >
              <button
                className="btn btn-primary"
                disabled={loading}
                type="submit"
                style={{ flex: 1 }}
              >
                {loading ? "Signing in..." : "Sign In"}
              </button>
            </div>
            <div
              style={{
                textAlign: "center",
                fontSize: "14px",
                color: "var(--gray)",
              }}
            >
              Don't have an account?{" "}
              <Link
                to="/register"
                style={{ color: "var(--primary)", textDecoration: "none" }}
              >
                Sign up
              </Link>
            </div>
          </form>
        </div>

        <div className="card" style={{ marginTop: "20px" }}>
          <h3 style={{ fontSize: "16px", marginBottom: "16px" }}>
            Demo Accounts
          </h3>
          <div
            style={{
              fontSize: "14px",
              color: "var(--gray)",
              lineHeight: "1.8",
            }}
          >
            <div>
              <strong>Admin:</strong> admin@dash.com / admin123
            </div>
            <div>
              <strong>Support:</strong> support@dash.com / support123
            </div>
            <div>
              <strong>Professional:</strong> pro@dash.com / pro123
            </div>
            <div>
              <strong>User:</strong> user@dash.com / user123
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
