const express = require('express');
const { v4: uuidv4 } = require('uuid');

module.exports = (db) => {
    const router = express.Router();

    // Get current user profile
    router.get('/profile', (req, res) => {
        const token = req.headers.authorization?.split(' ')[1];
        if (!token) {
            return res.status(401).json({ success: false, message: 'Unauthorized' });
        }

        const user = db.users.find(u => u.id === req.query.userId);
        if (!user) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        const { password, ...userData } = user;
        res.json({ success: true, user: userData });
    });

    // Update user profile
    router.put('/profile', (req, res) => {
        const { userId, name, phone, location } = req.body;
        
        const userIndex = db.users.findIndex(u => u.id === userId);
        if (userIndex === -1) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        db.users[userIndex] = { ...db.users[userIndex], name, phone, location };
        
        const { password, ...userData } = db.users[userIndex];
        res.json({ success: true, user: userData });
    });

    // Get user bookings
    router.get('/bookings', (req, res) => {
        const userId = req.query.userId;
        const userBookings = db.bookings.filter(b => b.userId === userId);
        
        const bookingsWithDetails = userBookings.map(booking => {
            const service = db.services.find(s => s.id === booking.serviceId);
            const professional = db.professionals.find(p => p.id === booking.professionalId);
            return { ...booking, service, professional };
        });

        res.json({ success: true, bookings: bookingsWithDetails });
    });

    // Get user reviews
    router.get('/reviews', (req, res) => {
        const userId = req.query.userId;
        const userReviews = db.reviews.filter(r => r.userId === userId);
        res.json({ success: true, reviews: userReviews });
    });

    // Get support tickets
    router.get('/tickets', (req, res) => {
        const userId = req.query.userId;
        const userTickets = db.supportTickets.filter(t => t.userId === userId);
        res.json({ success: true, tickets: userTickets });
    });

    return router;
};
