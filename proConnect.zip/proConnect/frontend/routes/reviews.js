const express = require('express');
const { v4: uuidv4 } = require('uuid');

module.exports = (db) => {
    const router = express.Router();

    // Get all reviews (for admin)
    router.get('/', (req, res) => {
        const { professionalId } = req.query;
        let reviews = [...db.reviews];

        if (professionalId) {
            reviews = reviews.filter(r => r.professionalId === professionalId);
        }

        res.json({ success: true, reviews });
    });

    // Create review
    router.post('/', (req, res) => {
        const { professionalId, userId, userName, rating, comment } = req.body;

        const newReview = {
            id: uuidv4(),
            professionalId,
            userId,
            userName,
            rating,
            comment,
            date: new Date().toISOString().split('T')[0]
        };

        db.reviews.push(newReview);

        // Update professional rating
        const professional = db.professionals.find(p => p.id === professionalId);
        if (professional) {
            const professionalReviews = db.reviews.filter(r => r.professionalId === professionalId);
            const totalRating = professionalReviews.reduce((sum, r) => sum + r.rating, 0);
            professional.rating = totalRating / professionalReviews.length;
            professional.reviewCount = professionalReviews.length;
        }

        res.json({ success: true, review: newReview });
    });

    // Delete review (admin)
    router.delete('/:id', (req, res) => {
        const reviewIndex = db.reviews.findIndex(r => r.id === req.params.id);
        if (reviewIndex === -1) {
            return res.status(404).json({ success: false, message: 'Review not found' });
        }

        db.reviews.splice(reviewIndex, 1);
        res.json({ success: true, message: 'Review deleted' });
    });

    return router;
};
