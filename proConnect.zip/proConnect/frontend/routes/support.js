const express = require('express');
const { v4: uuidv4 } = require('uuid');

module.exports = (db) => {
    const router = express.Router();

    // Get all tickets (for support/admin)
    router.get('/', (req, res) => {
        const { status, priority } = req.query;
        let tickets = [...db.supportTickets];

        if (status) {
            tickets = tickets.filter(t => t.status === status);
        }
        if (priority) {
            tickets = tickets.filter(t => t.priority === priority);
        }

        res.json({ success: true, tickets });
    });

    // Get single ticket
    router.get('/:id', (req, res) => {
        const ticket = db.supportTickets.find(t => t.id === req.params.id);
        if (!ticket) {
            return res.status(404).json({ success: false, message: 'Ticket not found' });
        }

        res.json({ success: true, ticket });
    });

    // Create ticket (user)
    router.post('/', (req, res) => {
        const { userId, userName, subject, message, priority = 'low' } = req.body;

        const newTicket = {
            id: uuidv4(),
            userId,
            userName,
            subject,
            message,
            status: 'open',
            priority,
            createdAt: new Date().toISOString().split('T')[0],
            response: null
        };

        db.supportTickets.push(newTicket);
        res.json({ success: true, ticket: newTicket });
    });

    // Respond to ticket (support/admin)
    router.put('/:id', (req, res) => {
        const { response, status } = req.body;
        
        const ticketIndex = db.supportTickets.findIndex(t => t.id === req.params.id);
        if (ticketIndex === -1) {
            return res.status(404).json({ success: false, message: 'Ticket not found' });
        }

        db.supportTickets[ticketIndex] = {
            ...db.supportTickets[ticketIndex],
            response,
            status: status || db.supportTickets[ticketIndex].status
        };

        res.json({ success: true, ticket: db.supportTickets[ticketIndex] });
    });

    // Delete ticket (admin)
    router.delete('/:id', (req, res) => {
        const ticketIndex = db.supportTickets.findIndex(t => t.id === req.params.id);
        if (ticketIndex === -1) {
            return res.status(404).json({ success: false, message: 'Ticket not found' });
        }

        db.supportTickets.splice(ticketIndex, 1);
        res.json({ success: true, message: 'Ticket deleted' });
    });

    return router;
};
