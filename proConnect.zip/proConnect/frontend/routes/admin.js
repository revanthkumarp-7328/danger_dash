const express = require('express');
const bcrypt = require('bcryptjs');

module.exports = (db) => {
    const router = express.Router();

    // Get dashboard stats
    router.get('/stats', (req, res) => {
        const stats = {
            totalUsers: db.users.length,
            totalProfessionals: db.professionals.length,
            totalServices: db.services.length,
            totalBookings: db.bookings.length,
            totalReviews: db.reviews.length,
            totalTickets: db.supportTickets.length,
            pendingTickets: db.supportTickets.filter(t => t.status === 'open').length,
            pendingBookings: db.bookings.filter(b => b.status === 'pending').length
        };

        res.json({ success: true, stats });
    });

    // Get all users
    router.get('/users', (req, res) => {
        const users = db.users.map(u => {
            const { password, ...userData } = u;
            return userData;
        });
        res.json({ success: true, users });
    });

    // Update user role
    router.put('/users/:id', (req, res) => {
        const { role } = req.body;
        
        const userIndex = db.users.findIndex(u => u.id === req.params.id);
        if (userIndex === -1) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        db.users[userIndex].role = role;
        
        const { password, ...userData } = db.users[userIndex];
        res.json({ success: true, user: userData });
    });

    // Delete user
    router.delete('/users/:id', (req, res) => {
        const userIndex = db.users.findIndex(u => u.id === req.params.id);
        if (userIndex === -1) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        const user = db.users[userIndex];
        db.users.splice(userIndex, 1);

        // Also remove from professionals if professional
        if (user.role === 'professional') {
            const profIndex = db.professionals.findIndex(p => p.id === user.id);
            if (profIndex !== -1) {
                db.professionals.splice(profIndex, 1);
            }
        }

        res.json({ success: true, message: 'User deleted' });
    });

    // Get all bookings
    router.get('/bookings', (req, res) => {
        const { status } = req.query;
        let bookings = [...db.bookings];

        if (status) {
            bookings = bookings.filter(b => b.status === status);
        }

        const bookingsWithDetails = bookings.map(booking => {
            const service = db.services.find(s => s.id === booking.serviceId);
            const professional = db.professionals.find(p => p.id === booking.professionalId);
            const user = db.users.find(u => u.id === booking.userId);
            return { ...booking, service, professional, user };
        });

        res.json({ success: true, bookings: bookingsWithDetails });
    });

    // Update booking status
    router.put('/bookings/:id', (req, res) => {
        const { status } = req.body;
        
        const bookingIndex = db.bookings.findIndex(b => b.id === req.params.id);
        if (bookingIndex === -1) {
            return res.status(404).json({ success: false, message: 'Booking not found' });
        }

        db.bookings[bookingIndex].status = status;
        res.json({ success: true, booking: db.bookings[bookingIndex] });
    });

    // Get all tickets
    router.get('/tickets', (req, res) => {
        const { status } = req.query;
        let tickets = [...db.supportTickets];

        if (status) {
            tickets = tickets.filter(t => t.status === status);
        }

        res.json({ success: true, tickets });
    });

    // Update ticket
    router.put('/tickets/:id', (req, res) => {
        const { status, response } = req.body;
        
        const ticketIndex = db.supportTickets.findIndex(t => t.id === req.params.id);
        if (ticketIndex === -1) {
            return res.status(404).json({ success: false, message: 'Ticket not found' });
        }

        db.supportTickets[ticketIndex] = {
            ...db.supportTickets[ticketIndex],
            status,
            response
        };

        res.json({ success: true, ticket: db.supportTickets[ticketIndex] });
    });

    // Verify professional
    router.put('/professionals/:id/verify', (req, res) => {
        const { verified } = req.body;
        
        const profIndex = db.professionals.findIndex(p => p.id === req.params.id);
        if (profIndex === -1) {
            return res.status(404).json({ success: false, message: 'Professional not found' });
        }

        db.professionals[profIndex].verified = verified;
        res.json({ success: true, professional: db.professionals[profIndex] });
    });

    // Get all reviews
    router.get('/reviews', (req, res) => {
        const reviews = db.reviews.map(review => {
            const professional = db.professionals.find(p => p.id === review.professionalId);
            return { ...review, professional };
        });
        res.json({ success: true, reviews });
    });

    // Delete review
    router.delete('/reviews/:id', (req, res) => {
        const reviewIndex = db.reviews.findIndex(r => r.id === req.params.id);
        if (reviewIndex === -1) {
            return res.status(404).json({ success: false, message: 'Review not found' });
        }

        db.reviews.splice(reviewIndex, 1);
        res.json({ success: true, message: 'Review deleted' });
    });

    return router;
};
