const express = require('express');

module.exports = (db) => {
    const router = express.Router();

    // Get all categories
    router.get('/', (req, res) => {
        res.json({ success: true, categories: db.categories });
    });

    // Get category by id
    router.get('/:id', (req, res) => {
        const category = db.categories.find(c => c.id === req.params.id);
        if (!category) {
            return res.status(404).json({ success: false, message: 'Category not found' });
        }
        res.json({ success: true, category });
    });

    return router;
};
