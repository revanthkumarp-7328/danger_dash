const express = require('express');
const { v4: uuidv4 } = require('uuid');

module.exports = (db) => {
    const router = express.Router();

    // Get all services
    router.get('/', (req, res) => {
        const { category, search } = req.query;
        let services = [...db.services];

        if (category && category !== 'all') {
            services = services.filter(s => s.category === category);
        }

        if (search) {
            const searchLower = search.toLowerCase();
            services = services.filter(s => 
                s.title.toLowerCase().includes(searchLower) ||
                s.description.toLowerCase().includes(searchLower)
            );
        }

        const servicesWithDetails = services.map(service => {
            const professional = db.professionals.find(p => p.id === service.professionalId);
            return { ...service, professional };
        });

        res.json({ success: true, services: servicesWithDetails });
    });

    // Get single service
    router.get('/:id', (req, res) => {
        const service = db.services.find(s => s.id === req.params.id);
        if (!service) {
            return res.status(404).json({ success: false, message: 'Service not found' });
        }

        const professional = db.professionals.find(p => p.id === service.professionalId);
        res.json({ success: true, service, professional });
    });

    // Create service (for professionals)
    router.post('/', (req, res) => {
        const { professionalId, title, description, category, price, duration } = req.body;

        const newService = {
            id: uuidv4(),
            professionalId,
            title,
            description,
            category,
            price: parseFloat(price),
            duration,
            rating: 0,
            createdAt: new Date().toISOString()
        };

        db.services.push(newService);
        res.json({ success: true, service: newService });
    });

    // Update service
    router.put('/:id', (req, res) => {
        const { title, description, category, price, duration } = req.body;
        
        const serviceIndex = db.services.findIndex(s => s.id === req.params.id);
        if (serviceIndex === -1) {
            return res.status(404).json({ success: false, message: 'Service not found' });
        }

        db.services[serviceIndex] = {
            ...db.services[serviceIndex],
            title,
            description,
            category,
            price: parseFloat(price),
            duration
        };

        res.json({ success: true, service: db.services[serviceIndex] });
    });

    // Delete service
    router.delete('/:id', (req, res) => {
        const serviceIndex = db.services.findIndex(s => s.id === req.params.id);
        if (serviceIndex === -1) {
            return res.status(404).json({ success: false, message: 'Service not found' });
        }

        db.services.splice(serviceIndex, 1);
        res.json({ success: true, message: 'Service deleted' });
    });

    return router;
};
