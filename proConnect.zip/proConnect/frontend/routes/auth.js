const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');

const JWT_SECRET = 'proconnect-secret-key-2026';

module.exports = (db) => {
    const router = express.Router();

    // Register
    router.post('/register', (req, res) => {
        try {
            const { email, password, name, role = 'user', title, bio, category, hourlyRate } = req.body;

            // Check if user exists
            const existingUser = db.users.find(u => u.email === email);
            if (existingUser) {
                return res.status(400).json({ success: false, message: 'Email already registered' });
            }

            const hashedPassword = bcrypt.hashSync(password, 10);
            const userId = uuidv4();

            const newUser = {
                id: userId,
                email,
                password: hashedPassword,
                name,
                role,
                createdAt: new Date().toISOString()
            };

            db.users.push(newUser);

            // If professional, also add to professionals array
            if (role === 'professional') {
                const newProfessional = {
                    id: userId,
                    userId: userId,
                    email,
                    name,
                    title: title || '',
                    bio: bio || '',
                    category: category || '',
                    hourlyRate: hourlyRate || 0,
                    rating: 0,
                    reviewCount: 0,
                    verified: false,
                    location: '',
                    phone: '',
                    image: `https://randomuser.me/api/portraits/${Math.random() > 0.5 ? 'men' : 'women'}/${Math.floor(Math.random() * 99)}.jpg`,
                    skills: [],
                    availability: '',
                    createdAt: new Date().toISOString()
                };
                db.professionals.push(newProfessional);
            }

            const token = jwt.sign({ id: userId, email, role }, JWT_SECRET, { expiresIn: '7d' });

            res.json({
                success: true,
                message: 'Registration successful',
                token,
                user: { id: userId, email, name, role }
            });
        } catch (error) {
            res.status(500).json({ success: false, message: 'Server error' });
        }
    });

    // Login
    router.post('/login', (req, res) => {
        try {
            const { email, password } = req.body;

            const user = db.users.find(u => u.email === email);
            if (!user) {
                return res.status(400).json({ success: false, message: 'Invalid credentials' });
            }

            const isMatch = bcrypt.compareSync(password, user.password);
            if (!isMatch) {
                return res.status(400).json({ success: false, message: 'Invalid credentials' });
            }

            const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '7d' });

            res.json({
                success: true,
                message: 'Login successful',
                token,
                user: { id: user.id, email: user.email, name: user.name, role: user.role }
            });
        } catch (error) {
            res.status(500).json({ success: false, message: 'Server error' });
        }
    });

    // Verify token
    router.get('/verify', (req, res) => {
        try {
            const token = req.headers.authorization?.split(' ')[1];
            if (!token) {
                return res.status(401).json({ success: false, message: 'No token provided' });
            }

            const decoded = jwt.verify(token, JWT_SECRET);
            const user = db.users.find(u => u.id === decoded.id);
            
            if (!user) {
                return res.status(401).json({ success: false, message: 'User not found' });
            }

            res.json({
                success: true,
                user: { id: user.id, email: user.email, name: user.name, role: user.role }
            });
        } catch (error) {
            res.status(401).json({ success: false, message: 'Invalid token' });
        }
    });

    return router;
};
