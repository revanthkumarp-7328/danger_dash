const express = require('express');
const { v4: uuidv4 } = require('uuid');

module.exports = (db) => {
    const router = express.Router();

    // Get all bookings (for admin/support)
    router.get('/', (req, res) => {
        const { status, professionalId, userId } = req.query;
        let bookings = [...db.bookings];

        if (status) {
            bookings = bookings.filter(b => b.status === status);
        }
        if (professionalId) {
            bookings = bookings.filter(b => b.professionalId === professionalId);
        }
        if (userId) {
            bookings = bookings.filter(b => b.userId === userId);
        }

        const bookingsWithDetails = bookings.map(booking => {
            const service = db.services.find(s => s.id === booking.serviceId);
            const professional = db.professionals.find(p => p.id === booking.professionalId);
            const user = db.users.find(u => u.id === booking.userId);
            return { ...booking, service, professional, user };
        });

        res.json({ success: true, bookings: bookingsWithDetails });
    });

    // Get single booking
    router.get('/:id', (req, res) => {
        const booking = db.bookings.find(b => b.id === req.params.id);
        if (!booking) {
            return res.status(404).json({ success: false, message: 'Booking not found' });
        }

        const service = db.services.find(s => s.id === booking.serviceId);
        const professional = db.professionals.find(p => p.id === booking.professionalId);
        const user = db.users.find(u => u.id === booking.userId);

        res.json({ success: true, booking: { ...booking, service, professional, user } });
    });

    // Create booking
    router.post('/', (req, res) => {
        const { userId, serviceId, professionalId, date, time, notes } = req.body;

        const service = db.services.find(s => s.id === serviceId);
        if (!service) {
            return res.status(404).json({ success: false, message: 'Service not found' });
        }

        const newBooking = {
            id: uuidv4(),
            userId,
            serviceId,
            professionalId,
            status: 'pending',
            date,
            time,
            totalAmount: service.price,
            notes: notes || '',
            createdAt: new Date().toISOString()
        };

        db.bookings.push(newBooking);
        res.json({ success: true, booking: newBooking });
    });

    // Update booking status
    router.put('/:id', (req, res) => {
        const { status } = req.body;
        
        const bookingIndex = db.bookings.findIndex(b => b.id === req.params.id);
        if (bookingIndex === -1) {
            return res.status(404).json({ success: false, message: 'Booking not found' });
        }

        db.bookings[bookingIndex] = {
            ...db.bookings[bookingIndex],
            status
        };

        res.json({ success: true, booking: db.bookings[bookingIndex] });
    });

    // Cancel booking
    router.delete('/:id', (req, res) => {
        const bookingIndex = db.bookings.findIndex(b => b.id === req.params.id);
        if (bookingIndex === -1) {
            return res.status(404).json({ success: false, message: 'Booking not found' });
        }

        db.bookings.splice(bookingIndex, 1);
        res.json({ success: true, message: 'Booking cancelled' });
    });

    return router;
};
