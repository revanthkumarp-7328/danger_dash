const express = require('express');

module.exports = (db) => {
    const router = express.Router();

    // Get all professionals
    router.get('/', (req, res) => {
        const { category, search, sort } = req.query;
        let professionals = [...db.professionals];

        if (category && category !== 'all') {
            professionals = professionals.filter(p => p.category === category);
        }

        if (search) {
            const searchLower = search.toLowerCase();
            professionals = professionals.filter(p => 
                p.name.toLowerCase().includes(searchLower) ||
                p.title.toLowerCase().includes(searchLower) ||
                p.category.toLowerCase().includes(searchLower) ||
                p.skills.some(s => s.toLowerCase().includes(searchLower))
            );
        }

        if (sort === 'rating') {
            professionals.sort((a, b) => b.rating - a.rating);
        } else if (sort === 'price-low') {
            professionals.sort((a, b) => a.hourlyRate - b.hourlyRate);
        } else if (sort === 'price-high') {
            professionals.sort((a, b) => b.hourlyRate - a.hourlyRate);
        }

        res.json({ success: true, professionals });
    });

    // Get single professional
    router.get('/:id', (req, res) => {
        const professional = db.professionals.find(p => p.id === req.params.id);
        if (!professional) {
            return res.status(404).json({ success: false, message: 'Professional not found' });
        }

        const services = db.services.filter(s => s.professionalId === professional.id);
        const reviews = db.reviews.filter(r => r.professionalId === professional.id);

        res.json({ success: true, professional, services, reviews });
    });

    // Get professional profile (for logged in professional)
    router.get('/me/profile', (req, res) => {
        const professionalId = req.query.id;
        const professional = db.professionals.find(p => p.id === professionalId);
        
        if (!professional) {
            return res.status(404).json({ success: false, message: 'Professional not found' });
        }

        const services = db.services.filter(s => s.professionalId === professional.id);
        const reviews = db.reviews.filter(r => r.professionalId === professional.id);
        const bookings = db.bookings.filter(b => b.professionalId === professional.id);

        res.json({ success: true, professional, services, reviews, bookings });
    });

    // Update professional profile
    router.put('/profile', (req, res) => {
        const { id, name, title, bio, category, hourlyRate, location, phone, skills, availability } = req.body;
        
        const profIndex = db.professionals.findIndex(p => p.id === id);
        if (profIndex === -1) {
            return res.status(404).json({ success: false, message: 'Professional not found' });
        }

        db.professionals[profIndex] = {
            ...db.professionals[profIndex],
            name,
            title,
            bio,
            category,
            hourlyRate: parseFloat(hourlyRate),
            location,
            phone,
            skills: skills || [],
            availability
        };

        res.json({ success: true, professional: db.professionals[profIndex] });
    });

    // Get professional bookings
    router.get('/bookings', (req, res) => {
        const professionalId = req.query.professionalId;
        const bookings = db.bookings.filter(b => b.professionalId === professionalId);

        const bookingsWithDetails = bookings.map(booking => {
            const service = db.services.find(s => s.id === booking.serviceId);
            return { ...booking, service };
        });

        res.json({ success: true, bookings: bookingsWithDetails });
    });

    return router;
};
