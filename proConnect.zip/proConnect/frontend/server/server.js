const express = require("express");
const cors = require("cors");
const path = require("path");
const http = require("http");

const app = express();
const PORT = process.env.PORT || 3000;
const BACKEND_URL = process.env.BACKEND_URL || "http://localhost:8080";

// Middleware
app.use(cors());
app.use(express.static(path.join(__dirname, "../public")));

// Reverse proxy: forward /api/* to Spring Boot backend
app.use("/api", (req, res) => {
  const target = new URL(BACKEND_URL);

  const options = {
    hostname: target.hostname,
    port: target.port || 80,
    path: req.originalUrl,
    method: req.method,
    headers: {
      ...req.headers,
      host: target.host,
    },
  };

  const proxyReq = http.request(options, (proxyRes) => {
    res.statusCode = proxyRes.statusCode || 500;
    Object.entries(proxyRes.headers).forEach(([k, v]) => {
      if (v !== undefined) res.setHeader(k, v);
    });
    proxyRes.pipe(res, { end: true });
  });

  proxyReq.on("error", () => {
    res
      .status(502)
      .json({ error: "bad_gateway", message: "Backend unavailable" });
  });

  if (req.method === "GET" || req.method === "HEAD") {
    proxyReq.end();
  } else {
    req.pipe(proxyReq, { end: true });
  }
});

// Serve frontend
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "../public/index.html"));
});

app.listen(PORT, () => {
  console.log(`🚀 ProConnect server running on http://localhost:${PORT}`);
});
