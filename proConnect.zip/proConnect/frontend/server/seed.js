const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

function seedData(db) {
    // Create admin user
    const adminUser = {
        id: uuidv4(),
        email: 'admin@proconnect.com',
        password: bcrypt.hashSync('admin123', 10),
        name: 'System Admin',
        role: 'admin',
        createdAt: new Date().toISOString()
    };
    db.users.push(adminUser);

    // Create support user
    const supportUser = {
        id: uuidv4(),
        email: 'support@proconnect.com',
        password: bcrypt.hashSync('support123', 10),
        name: 'Customer Support',
        role: 'support',
        createdAt: new Date().toISOString()
    };
    db.users.push(supportUser);

    // Create sample professionals
    const professionals = [
        {
            id: uuidv4(),
            userId: '',
            email: 'john.doe@email.com',
            password: bcrypt.hashSync('john123', 10),
            name: 'John Doe',
            role: 'professional',
            title: 'Master Electrician',
            bio: 'Certified electrician with 15 years of experience in residential and commercial electrical work. Specialized in smart home installations and emergency repairs.',
            category: 'Home Services',
            hourlyRate: 75,
            rating: 4.8,
            reviewCount: 127,
            verified: true,
            location: 'New York, NY',
            phone: '+1 (555) 123-4567',
            image: 'https://randomuser.me/api/portraits/men/1.jpg',
            skills: ['Electrical Repairs', 'Smart Home Installation', 'Wiring', 'Panel Upgrade', 'Emergency Services'],
            availability: 'Mon-Sat: 8AM-6PM',
            createdAt: new Date().toISOString()
        },
        {
            id: uuidv4(),
            userId: '',
            email: 'sarah.smith@email.com',
            password: bcrypt.hashSync('sarah123', 10),
            name: 'Sarah Smith',
            role: 'professional',
            title: 'Full Stack Developer',
            bio: 'Experienced full-stack developer specializing in React, Node.js, and cloud solutions. Built applications for startups and Fortune 500 companies.',
            category: 'Technology',
            hourlyRate: 120,
            rating: 4.9,
            reviewCount: 89,
            verified: true,
            location: 'San Francisco, CA',
            phone: '+1 (555) 234-5678',
            image: 'https://randomuser.me/api/portraits/women/2.jpg',
            skills: ['React', 'Node.js', 'AWS', 'TypeScript', 'PostgreSQL'],
            availability: 'Remote Available',
            createdAt: new Date().toISOString()
        },
        {
            id: uuidv4(),
            userId: '',
            email: 'mike.wilson@email.com',
            password: bcrypt.hashSync('mike123', 10),
            name: 'Mike Wilson',
            role: 'professional',
            title: 'Professional Plumber',
            bio: 'Licensed plumber with expertise in pipe fitting, water heater installation, and leak detection. Available 24/7 for emergencies.',
            category: 'Home Services',
            hourlyRate: 85,
            rating: 4.7,
            reviewCount: 203,
            verified: true,
            location: 'Chicago, IL',
            phone: '+1 (555) 345-6789',
            image: 'https://randomuser.me/api/portraits/men/3.jpg',
            skills: ['Pipe Fitting', 'Water Heater', 'Leak Detection', 'Drain Cleaning', 'Bathroom Remodeling'],
            availability: '24/7 Emergency',
            createdAt: new Date().toISOString()
        },
        {
            id: uuidv4(),
            userId: '',
            email: 'emily.chen@email.com',
            password: bcrypt.hashSync('emily123', 10),
            name: 'Emily Chen',
            role: 'professional',
            title: 'UX/UI Designer',
            bio: 'Award-winning designer with 10 years of experience creating beautiful, user-centered designs for web and mobile applications.',
            category: 'Design & Creative',
            hourlyRate: 95,
            rating: 5.0,
            reviewCount: 64,
            verified: true,
            location: 'Los Angeles, CA',
            phone: '+1 (555) 456-7890',
            image: 'https://randomuser.me/api/portraits/women/4.jpg',
            skills: ['UI Design', 'UX Research', 'Figma', 'Adobe XD', 'Prototyping'],
            availability: 'Mon-Fri: 9AM-5PM',
            createdAt: new Date().toISOString()
        },
        {
            id: uuidv4(),
            userId: '',
            email: 'david.brown@email.com',
            password: bcrypt.hashSync('david123', 10),
            name: 'David Brown',
            role: 'professional',
            title: 'Personal Trainer',
            bio: 'Certified personal trainer specializing in strength training, weight loss, and sports performance. Creating customized fitness programs for all levels.',
            category: 'Health & Wellness',
            hourlyRate: 60,
            rating: 4.9,
            reviewCount: 156,
            verified: true,
            location: 'Miami, FL',
            phone: '+1 (555) 567-8901',
            image: 'https://randomuser.me/api/portraits/men/5.jpg',
            skills: ['Strength Training', 'Weight Loss', 'Sports Performance', 'Nutrition', 'Yoga'],
            availability: 'Flexible Schedule',
            createdAt: new Date().toISOString()
        },
        {
            id: uuidv4(),
            userId: '',
            email: 'lisa.johnson@email.com',
            password: bcrypt.hashSync('lisa123', 10),
            name: 'Lisa Johnson',
            role: 'professional',
            title: 'Math Tutor',
            bio: 'PhD in Mathematics with 8 years of teaching experience. Making complex math concepts simple and enjoyable for students of all ages.',
            category: 'Education',
            hourlyRate: 50,
            rating: 4.8,
            reviewCount: 92,
            verified: true,
            location: 'Boston, MA',
            phone: '+1 (555) 678-9012',
            image: 'https://randomuser.me/api/portraits/women/6.jpg',
            skills: ['Calculus', 'Algebra', 'Statistics', 'SAT Prep', 'GRE Math'],
            availability: 'After School & Weekends',
            createdAt: new Date().toISOString()
        }
    ];

    professionals.forEach(p => {
        db.professionals.push(p);
        db.users.push({
            id: p.id,
            email: p.email,
            password: p.password,
            name: p.name,
            role: 'professional',
            createdAt: p.createdAt
        });
    });

    // Create sample services
    const services = [
        {
            id: uuidv4(),
            professionalId: professionals[0].id,
            title: 'Electrical Inspection & Repair',
            description: 'Complete electrical system inspection, troubleshooting, and repair services. Includes safety checks and code compliance.',
            category: 'Home Services',
            price: 150,
            duration: '2-3 hours',
            rating: 4.8
        },
        {
            id: uuidv4(),
            professionalId: professionals[1].id,
            title: 'Web Application Development',
            description: 'Custom web application development using React, Node.js, and cloud technologies. From concept to deployment.',
            category: 'Technology',
            price: 5000,
            duration: '2-4 weeks',
            rating: 4.9
        },
        {
            id: uuidv4(),
            professionalId: professionals[2].id,
            title: 'Plumbing Emergency Service',
            description: '24/7 emergency plumbing services including leak repair, pipe replacement, and drain cleaning.',
            category: 'Home Services',
            price: 200,
            duration: '1-2 hours',
            rating: 4.7
        },
        {
            id: uuidv4(),
            professionalId: professionals[3].id,
            title: 'UI/UX Design Package',
            description: 'Complete UI/UX design solution including user research, wireframes, high-fidelity prototypes, and design system.',
            category: 'Design & Creative',
            price: 2500,
            duration: '2-3 weeks',
            rating: 5.0
        },
        {
            id: uuidv4(),
            professionalId: professionals[4].id,
            title: 'Personal Training Session',
            description: 'One-on-one personalized training session tailored to your fitness goals. Includes workout plan and nutrition guidance.',
            category: 'Health & Wellness',
            price: 75,
            duration: '1 hour',
            rating: 4.9
        },
        {
            id: uuidv4(),
            professionalId: professionals[5].id,
            title: 'Mathematics Tutoring',
            description: 'Personalized math tutoring for all levels. Specializing in calculus, algebra, statistics, and test preparation.',
            category: 'Education',
            price: 60,
            duration: '1 hour',
            rating: 4.8
        }
    ];

    db.services.push(...services);

    // Create sample bookings
    const bookings = [
        {
            id: uuidv4(),
            userId: 'sample-user-1',
            serviceId: services[0].id,
            professionalId: professionals[0].id,
            status: 'completed',
            date: '2026-02-15',
            time: '10:00 AM',
            totalAmount: 150,
            notes: 'Need electrical inspection for new home',
            createdAt: new Date().toISOString()
        },
        {
            id: uuidv4(),
            userId: 'sample-user-2',
            serviceId: services[1].id,
            professionalId: professionals[1].id,
            status: 'pending',
            date: '2026-02-28',
            time: '2:00 PM',
            totalAmount: 5000,
            notes: 'Looking for e-commerce website',
            createdAt: new Date().toISOString()
        }
    ];

    db.bookings.push(...bookings);

    // Create sample reviews
    const reviews = [
        {
            id: uuidv4(),
            professionalId: professionals[0].id,
            userId: 'sample-user-1',
            userName: 'Alex Thompson',
            rating: 5,
            comment: 'Excellent work! John was very professional and completed the job quickly. Highly recommend!',
            date: '2026-02-16'
        },
        {
            id: uuidv4(),
            professionalId: professionals[1].id,
            userId: 'sample-user-3',
            userName: 'Jennifer Lee',
            rating: 5,
            comment: 'Sarah is an amazing developer. Delivered our project on time and exceeded expectations!',
            date: '2026-02-10'
        },
        {
            id: uuidv4(),
            professionalId: professionals[2].id,
            userId: 'sample-user-4',
            userName: 'Robert Garcia',
            rating: 4,
            comment: 'Great plumber! Fixed the leak quickly and reasonably priced. Will definitely hire again.',
            date: '2026-02-08'
        }
    ];

    db.reviews.push(...reviews);

    // Create sample support tickets
    const supportTickets = [
        {
            id: uuidv4(),
            userId: 'sample-user-1',
            userName: 'Alex Thompson',
            subject: 'Payment Issue',
            message: 'I was charged twice for a service. Please help!',
            status: 'resolved',
            priority: 'high',
            createdAt: '2026-02-14',
            response: 'We have processed the refund. It should reflect in your account within 3-5 business days.'
        },
        {
            id: uuidv4(),
            userId: 'sample-user-2',
            userName: 'Jennifer Lee',
            subject: 'How to hire a professional?',
            message: 'I am new to this platform. How do I hire a professional for my project?',
            status: 'open',
            priority: 'low',
            createdAt: '2026-02-20',
            response: null
        }
    ];

    db.supportTickets.push(...supportTickets);

    console.log('✅ Database seeded successfully!');
}

module.exports = seedData;
