package com.dash.marketplace.service;

import com.dash.marketplace.api.dto.BookingDtos;
import com.dash.marketplace.domain.*;
import com.dash.marketplace.repo.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZoneId;

@Service
public class BookingService {

    private final BookingRepository bookingRepository;
    private final UserRepository userRepository;
    private final ProfessionalServiceRepository professionalServiceRepository;
    private final ProfessionalProfileRepository professionalProfileRepository;
    private final NotificationService notificationService;

    public BookingService(BookingRepository bookingRepository,
                          UserRepository userRepository,
                          ProfessionalServiceRepository professionalServiceRepository,
                          ProfessionalProfileRepository professionalProfileRepository,
                          NotificationService notificationService) {
        this.bookingRepository = bookingRepository;
        this.userRepository = userRepository;
        this.professionalServiceRepository = professionalServiceRepository;
        this.professionalProfileRepository = professionalProfileRepository;
        this.notificationService = notificationService;
    }

    @Transactional
    public BookingDtos.BookingDto createBooking(Long clientUserId, BookingDtos.CreateBookingRequest req) {
        User client = userRepository.findById(clientUserId).orElseThrow();
        ProfessionalService ps = professionalServiceRepository.findById(req.professionalServiceId())
                .orElseThrow(() -> new IllegalArgumentException("Professional service not found"));

        ProfessionalProfile pro = ps.getProfile();
        if (pro.getVerificationStatus() != VerificationStatus.APPROVED) {
            throw new IllegalArgumentException("Professional is not approved yet");
        }
        if (!ps.isActive()) {
            throw new IllegalArgumentException("Service is not active");
        }

        Booking booking = new Booking(client, pro, ps, req.scheduledAt(), req.address(), ps.getBasePrice());
        booking = bookingRepository.save(booking);
        
        // Notify the professional about the new booking request
        notificationService.notify(
            pro.getUser(),
            "NEW_BOOKING_REQUEST",
            "New Booking Request",
            String.format("You have a new booking request from %s for %s.", client.getFullName(), ps.getTitle())
        );
        
        return toDto(booking);
    }

    public Page<BookingDtos.BookingDto> myBookingsAsClient(Long clientUserId, Pageable pageable) {
        return bookingRepository.findByClientId(clientUserId, pageable).map(this::toDto);
    }

    public Page<BookingDtos.BookingDto> myBookingsAsProfessional(Long professionalProfileId, BookingStatus status, Pageable pageable) {
        if (status == null) {
            return bookingRepository.findByProfessionalId(professionalProfileId, pageable).map(this::toDto);
        }
        return bookingRepository.findByProfessionalIdAndStatus(professionalProfileId, status, pageable).map(this::toDto);
    }

    @Transactional
    public BookingDtos.BookingDto cancelAsClient(Long clientUserId, Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId).orElseThrow();
        if (!booking.getClient().getId().equals(clientUserId)) {
            throw new IllegalArgumentException("Not your booking");
        }
        if (booking.getStatus() == BookingStatus.COMPLETED) {
            throw new IllegalArgumentException("Cannot cancel completed booking");
        }
        booking.setStatus(BookingStatus.CANCELLED);
        
        // Notify the professional about the cancellation
        notificationService.notify(
            booking.getProfessional().getUser(),
            "BOOKING_CANCELLED",
            "Booking Cancelled",
            String.format("Booking #%d has been cancelled by the client.", booking.getId())
        );
        
        return toDto(booking);
    }

    @Transactional
    public BookingDtos.BookingDto accept(Long professionalUserId, Long bookingId) {
        Booking booking = requireOwnedByProfessionalUser(professionalUserId, bookingId);
        if (booking.getStatus() != BookingStatus.PENDING) {
            throw new IllegalArgumentException("Booking not pending");
        }
        booking.setStatus(BookingStatus.ACCEPTED);
        
        // Notify the client that their booking has been accepted
        notificationService.notify(
            booking.getClient(),
            "BOOKING_ACCEPTED",
            "Booking Accepted",
            String.format("Your booking #%d for %s has been accepted by %s.", 
                booking.getId(), 
                booking.getProfessionalService().getTitle(),
                booking.getProfessional().getUser().getFullName())
        );
        
        return toDto(booking);
    }

    @Transactional
    public BookingDtos.BookingDto reject(Long professionalUserId, Long bookingId) {
        Booking booking = requireOwnedByProfessionalUser(professionalUserId, bookingId);
        if (booking.getStatus() != BookingStatus.PENDING) {
            throw new IllegalArgumentException("Booking not pending");
        }
        booking.setStatus(BookingStatus.REJECTED);
        
        // Notify the client that their booking has been rejected
        notificationService.notify(
            booking.getClient(),
            "BOOKING_REJECTED",
            "Booking Rejected",
            String.format("Your booking #%d for %s has been rejected by the professional.", 
                booking.getId(), 
                booking.getProfessionalService().getTitle())
        );
        
        return toDto(booking);
    }

    @Transactional
    public BookingDtos.BookingDto start(Long professionalUserId, Long bookingId) {
        Booking booking = requireOwnedByProfessionalUser(professionalUserId, bookingId);
        if (booking.getStatus() != BookingStatus.ACCEPTED) {
            throw new IllegalArgumentException("Booking not accepted");
        }
        booking.setStatus(BookingStatus.IN_PROGRESS);
        
        // Notify the client that their booking has started
        notificationService.notify(
            booking.getClient(),
            "BOOKING_STARTED",
            "Booking Started",
            String.format("Your booking #%d for %s has been started.", 
                booking.getId(), 
                booking.getProfessionalService().getTitle())
        );
        
        return toDto(booking);
    }

    @Transactional
    public BookingDtos.BookingDto complete(Long professionalUserId, Long bookingId) {
        Booking booking = requireOwnedByProfessionalUser(professionalUserId, bookingId);
        if (booking.getStatus() != BookingStatus.IN_PROGRESS) {
            throw new IllegalArgumentException("Booking not in progress");
        }
        booking.setStatus(BookingStatus.COMPLETED);
        
        // Notify the client that their booking has been completed
        notificationService.notify(
            booking.getClient(),
            "BOOKING_COMPLETED",
            "Booking Completed",
            String.format("Your booking #%d for %s has been completed. Please leave a review!", 
                booking.getId(), 
                booking.getProfessionalService().getTitle())
        );
        
        return toDto(booking);
    }

    private Booking requireOwnedByProfessionalUser(Long professionalUserId, Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId).orElseThrow();
        ProfessionalProfile profile = professionalProfileRepository.findByUserId(professionalUserId)
                .orElseThrow(() -> new IllegalArgumentException("Professional profile not found"));

        if (!booking.getProfessional().getId().equals(profile.getId())) {
            throw new IllegalArgumentException("Not your booking");
        }
        return booking;
    }

    private BookingDtos.BookingDto toDto(Booking b) {
        return new BookingDtos.BookingDto(
                b.getId(),
                b.getClient().getId(),
                b.getClient().getFullName(),
                b.getProfessional().getId(),
                b.getProfessional().getUser().getFullName(),
                b.getProfessionalService().getId(),
                b.getProfessionalService().getTitle(),
                b.getAgreedPrice(),
                b.getStatus().name(),
                b.getScheduledAt(),
                b.getAddress(),
                b.getCreatedAt().atZone(ZoneId.systemDefault()).toOffsetDateTime().toString(),
                b.getUpdatedAt().atZone(ZoneId.systemDefault()).toOffsetDateTime().toString()
        );
    }
}
