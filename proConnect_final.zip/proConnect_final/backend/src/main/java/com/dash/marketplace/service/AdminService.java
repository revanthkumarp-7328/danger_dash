package com.dash.marketplace.service;

import com.dash.marketplace.domain.*;
import com.dash.marketplace.repo.ProfessionalProfileRepository;
import com.dash.marketplace.repo.UserRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AdminService {

    private final ProfessionalProfileRepository professionalProfileRepository;
    private final UserRepository userRepository;
    private final NotificationService notificationService;

    public AdminService(ProfessionalProfileRepository professionalProfileRepository, UserRepository userRepository, NotificationService notificationService) {
        this.professionalProfileRepository = professionalProfileRepository;
        this.userRepository = userRepository;
        this.notificationService = notificationService;
    }

    public Page<ProfessionalProfile> pendingProfessionals(Pageable pageable) {
        return professionalProfileRepository.findByVerificationStatus(VerificationStatus.PENDING, pageable);
    }

    @Transactional
    public ProfessionalProfile approveProfessional(Long profileId) {
        ProfessionalProfile p = professionalProfileRepository.findById(profileId)
                .orElseThrow(() -> new IllegalArgumentException("Profile not found"));
        p.setVerificationStatus(VerificationStatus.APPROVED);
        
        // Notify the professional that their profile has been approved
        notificationService.notify(
            p.getUser(),
            "PROFILE_APPROVED",
            "Profile Approved",
            "Congratulations! Your professional profile has been approved by the admin."
        );
        
        return p;
    }

    @Transactional
    public ProfessionalProfile rejectProfessional(Long profileId) {
        ProfessionalProfile p = professionalProfileRepository.findById(profileId)
                .orElseThrow(() -> new IllegalArgumentException("Profile not found"));
        p.setVerificationStatus(VerificationStatus.REJECTED);
        
        // Notify the professional that their profile has been rejected
        notificationService.notify(
            p.getUser(),
            "PROFILE_REJECTED",
            "Profile Rejected",
            "Your professional profile has been rejected by the admin. Please review and submit again."
        );
        
        return p;
    }

    @Transactional
    public void suspendUser(Long userId) {
        User u = userRepository.findById(userId).orElseThrow(() -> new IllegalArgumentException("User not found"));
        u.setStatus(UserStatus.SUSPENDED);
        
        // Notify the user that their account has been suspended
        notificationService.notify(
            u,
            "ACCOUNT_SUSPENDED",
            "Account Suspended",
            "Your account has been suspended by the admin. Please contact support for more information."
        );
    }
}
