import React, { createContext, useContext, useMemo, useState } from "react";
import { apiFetch, setToken } from "../api/http.js";
import { disconnectWs } from "../api/ws.js";

const AuthContext = createContext(null);

function normalizeRole(roles = []) {
  if (roles.includes("ADMIN")) return "admin";
  if (roles.includes("SUPPORT")) return "support";
  if (roles.includes("PROFESSIONAL")) return "professional";
  return "user";
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const raw = localStorage.getItem("user");
    return raw ? JSON.parse(raw) : null;
  });

  const value = useMemo(() => {
    return {
      user,
      isAuthed: !!user,
      async login(email, password) {
        const data = await apiFetch("/api/auth/login", {
          method: "POST",
          body: JSON.stringify({ email, password }),
        });

        const role = normalizeRole(data.roles || []);
        const nextUser = {
          id: String(data.userId),
          email: data.email,
          name: data.fullName,
          role,
        };

        setToken(data.accessToken);
        localStorage.setItem("user", JSON.stringify(nextUser));
        setUser(nextUser);
        return nextUser;
      },
      async register(fullName, email, password, role) {
        const backendRole =
          role === "professional"
            ? "PROFESSIONAL"
            : role === "support"
              ? "SUPPORT"
              : role === "admin"
                ? "ADMIN"
                : "USER";

        const data = await apiFetch("/api/auth/register", {
          method: "POST",
          body: JSON.stringify({
            fullName,
            email,
            password,
            role: backendRole,
          }),
        });

        const nextUser = {
          id: String(data.userId),
          email: data.email,
          name: data.fullName,
          role: normalizeRole(data.roles || []),
        };

        setToken(data.accessToken);
        localStorage.setItem("user", JSON.stringify(nextUser));
        setUser(nextUser);
        return nextUser;
      },
      logout() {
        setToken(null);
        disconnectWs();
        // Keep user data in localStorage for persistence
        setUser(null);
      },
    };
  }, [user]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
