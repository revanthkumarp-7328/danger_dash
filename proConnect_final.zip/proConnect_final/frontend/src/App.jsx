import React, { useState, useEffect } from "react";
import {
  Navigate,
  Route,
  Routes,
  Link,
  useLocation,
  useNavigate,
} from "react-router-dom";
import { useAuth } from "./state/AuthContext.jsx";
import { apiFetch } from "./api/http.js";
import { subscribeTopic } from "./api/ws.js";
import LoginPage from "./pages/LoginPage.jsx";
import RegisterPage from "./pages/RegisterPage.jsx";
import HomePage from "./pages/HomePage.jsx";
import DashboardPage from "./pages/DashboardPage.jsx";
import TermsPage from "./pages/TermsPage.jsx";

function PrivateRoute({ children }) {
  const auth = useAuth();
  if (!auth.isAuthed) return <Navigate to="/login" replace />;
  return children;
}

function TopNav() {
  const auth = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  async function loadUnreadCount() {
    if (!auth.user?.id) return;
    try {
      const count = await apiFetch("/api/notifications/unread-count");
      setUnreadCount(count);
    } catch (e) {
      console.error("Failed to load unread count", e);
    }
  }

  useEffect(() => {
    loadUnreadCount();
    if (!auth.user?.id) return;
    let unsub = null;
    subscribeTopic(`/topic/notifications.${auth.user.id}`, (notification) => {
      setUnreadCount((prev) => prev + 1);
    })
      .then((u) => {
        unsub = u;
      })
      .catch(() => {});

    const handleNotificationRead = () => {
      loadUnreadCount();
    };

    window.addEventListener("notificationRead", handleNotificationRead);

    return () => {
      if (unsub) unsub();
      window.removeEventListener("notificationRead", handleNotificationRead);
    };
  }, [auth.user?.id]);

  async function goToSection(id) {
    if (location.pathname !== "/") {
      navigate("/");
      const deadline = Date.now() + 2000;
      const tick = () => {
        const el = document.getElementById(id);
        if (el) {
          el.scrollIntoView({ behavior: "smooth" });
          return;
        }
        if (Date.now() > deadline) return;
        requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
      return;
    }
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  }

  return (
    <nav className="navbar">
      <div className="navbar-container">
        <Link className="navbar-brand" to="/">
          <i className="fas fa-handshake"></i>
          ProConnect
        </Link>
        <div className="navbar-menu">
          <Link className="navbar-link" to="/">
            Home
          </Link>
          <button
            className="navbar-link"
            type="button"
            onClick={() => goToSection("categories")}
            style={{ border: "none", background: "none", cursor: "pointer" }}
          >
            Categories
          </button>
          <button
            className="navbar-link"
            type="button"
            onClick={() => goToSection("professionals")}
            style={{ border: "none", background: "none", cursor: "pointer" }}
          >
            Professionals
          </button>
          <button
            className="navbar-link"
            type="button"
            onClick={() => goToSection("services")}
            style={{ border: "none", background: "none", cursor: "pointer" }}
          >
            Services
          </button>
        </div>
        {!auth.isAuthed ? (
          <div className="navbar-auth">
            <button
              className="btn btn-outline"
              onClick={() => navigate("/login")}
            >
              Login
            </button>
            <button
              className="btn btn-primary"
              onClick={() => navigate("/register")}
            >
              Sign Up
            </button>
          </div>
        ) : (
          <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
            <Link
              to="/dashboard/notifications"
              style={{
                position: "relative",
                color: "inherit",
                textDecoration: "none",
              }}
            >
              <i className="fas fa-bell" style={{ fontSize: "20px" }}></i>
              {unreadCount > 0 && (
                <span
                  style={{
                    position: "absolute",
                    top: "-8px",
                    right: "-8px",
                    backgroundColor: "var(--primary)",
                    color: "white",
                    borderRadius: "50%",
                    width: "18px",
                    height: "18px",
                    fontSize: "12px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontWeight: "bold",
                  }}
                >
                  {unreadCount > 9 ? "9+" : unreadCount}
                </span>
              )}
            </Link>
            <div
              className="user-menu"
              onClick={() => setDropdownOpen(!dropdownOpen)}
            >
              <img
                src={`https://randomuser.me/api/portraits/men/${auth.user?.id || 1}.jpg`}
                alt="User"
                className="user-avatar"
              />
              <span>{auth.user?.name || auth.user?.email}</span>
              <i className="fas fa-chevron-down"></i>
              <div className={`user-dropdown ${dropdownOpen ? "active" : ""}`}>
                <Link
                  className="user-dropdown-item"
                  to="/dashboard"
                  onClick={() => setDropdownOpen(false)}
                >
                  <i className="fas fa-home"></i> Dashboard
                </Link>
                <Link
                  className="user-dropdown-item"
                  to="/dashboard/notifications"
                  onClick={() => {
                    setDropdownOpen(false);
                    setUnreadCount(0);
                  }}
                >
                  <i className="fas fa-bell"></i> Notifications
                </Link>
                <button
                  className="user-dropdown-item"
                  onClick={() => {
                    setDropdownOpen(false);
                    auth.logout();
                    navigate("/");
                  }}
                  style={{
                    border: "none",
                    background: "none",
                    cursor: "pointer",
                  }}
                >
                  <i className="fas fa-sign-out-alt"></i> Logout
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}

export default function App() {
  return (
    <>
      <TopNav />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/terms" element={<TermsPage />} />
        <Route
          path="/dashboard/*"
          element={
            <PrivateRoute>
              <DashboardPage />
            </PrivateRoute>
          }
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </>
  );
}
