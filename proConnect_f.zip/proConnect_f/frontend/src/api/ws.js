import { getToken } from "./http.js";

let client = null;
let connectPromise = null;
let stompClientCtor = null;
let sockJsCtor = null;

function apiBase() {
  return (import.meta?.env?.VITE_API_BASE_URL || "").replace(/\/$/, "");
}

export async function getStompClient() {
  if (client && client.connected) return client;
  if (connectPromise) return connectPromise;

  if (!stompClientCtor || !sockJsCtor) {
    const stompMod = await import("@stomp/stompjs");
    const sockjsMod = await import("sockjs-client");
    stompClientCtor = stompMod.Client;
    sockJsCtor = sockjsMod.default;
  }

  connectPromise = new Promise((resolve, reject) => {
    const token = getToken();
    const base = apiBase();
    const wsUrl = `${base || ""}/ws?token=${encodeURIComponent(token || "")}`;

    const c = new stompClientCtor({
      webSocketFactory: () => new sockJsCtor(wsUrl),
      reconnectDelay: 3000,
      connectHeaders: {},
      onConnect: () => {
        client = c;
        connectPromise = null;
        resolve(c);
      },
      onStompError: (frame) => {
        connectPromise = null;
        reject(new Error(frame?.headers?.message || "WebSocket error"));
      },
      onWebSocketError: () => {
        connectPromise = null;
        reject(new Error("WebSocket connection failed"));
      },
    });

    c.activate();
  });

  return connectPromise;
}

export async function subscribeTopic(topic, onMessage) {
  const c = await getStompClient();
  const sub = c.subscribe(topic, (msg) => {
    try {
      const body = msg.body ? JSON.parse(msg.body) : null;
      onMessage(body);
    } catch {
      onMessage(null);
    }
  });
  return () => sub.unsubscribe();
}

export function disconnectWs() {
  if (client) {
    client.deactivate();
    client = null;
  }
  connectPromise = null;
}
