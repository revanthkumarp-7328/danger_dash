import React from "react";
import { Link } from "react-router-dom";

export default function TermsPage() {
  return (
    <div className="container" style={{ padding: "40px 0" }}>
      <h1 style={{ marginBottom: 12 }}>Terms of Service</h1>
      <p style={{ marginBottom: 16, color: "var(--gray-700)" }}>
        These Terms of Service govern your use of ProConnect. By using the
        platform, you agree to these terms.
      </p>

      <h3 style={{ marginTop: 24, marginBottom: 8 }}>1. Accounts</h3>
      <p style={{ color: "var(--gray-700)" }}>
        You are responsible for maintaining the confidentiality of your account
        and for all activities that occur under your account.
      </p>

      <h3 style={{ marginTop: 24, marginBottom: 8 }}>2. Bookings & Payments</h3>
      <p style={{ color: "var(--gray-700)" }}>
        Booking availability, pricing, and payment terms may vary by service and
        professional. You agree to provide accurate information when booking a
        service.
      </p>

      <h3 style={{ marginTop: 24, marginBottom: 8 }}>3. Acceptable Use</h3>
      <p style={{ color: "var(--gray-700)" }}>
        You agree not to misuse the platform, attempt unauthorized access, or
        interfere with platform operations.
      </p>

      <h3 style={{ marginTop: 24, marginBottom: 8 }}>4. Support</h3>
      <p style={{ color: "var(--gray-700)" }}>
        For assistance, contact us at{" "}
        <a href="mailto:support@proconnect.com">support@proconnect.com</a>.
      </p>

      <div style={{ marginTop: 28 }}>
        <Link className="btn btn-outline" to="/">
          Back to Home
        </Link>
      </div>
    </div>
  );
}
