import React, { useEffect, useState } from "react";
import { apiFetch } from "../../api/http.js";
import { subscribeTopic } from "../../api/ws.js";
import { useAuth } from "../../state/AuthContext.jsx";

export default function NotificationsPage() {
  const auth = useAuth();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const data = await apiFetch("/api/notifications?page=0&size=50");
      setItems(data.content || []);
    } catch (e) {
      setError(e?.message || "Failed to load notifications");
      setItems([]);
    } finally {
      setLoading(false);
    }
  }

  async function markRead(notificationId) {
    try {
      await apiFetch("/api/notifications/mark-read", {
        method: "POST",
        body: JSON.stringify({ notificationId }),
      });
      await load();
    } catch (e) {
      alert(e?.message || "Failed to mark read");
    }
  }

  useEffect(() => {
    load();
    if (!auth.user?.id) return;
    let unsub = null;
    subscribeTopic(`/topic/notifications.${auth.user.id}`, () => {
      load();
    })
      .then((u) => {
        unsub = u;
      })
      .catch(() => {});

    return () => {
      if (unsub) unsub();
    };
  }, [auth.user?.id]);

  return (
    <>
      <div className="dashboard-header">
        <h1 className="dashboard-title">Notifications</h1>
        <button className="btn btn-outline" onClick={load} disabled={loading}>
          <i className="fas fa-sync-alt"></i> Refresh
        </button>
      </div>

      <div className="card">
        {error && (
          <div className="error" style={{ padding: "20px" }}>
            {error}
          </div>
        )}

        {loading ? (
          <div className="loading">Loading notifications...</div>
        ) : items.length === 0 ? (
          <div className="empty">No notifications</div>
        ) : (
          <div style={{ display: "grid", gap: "12px" }}>
            {items.map((n) => (
              <div
                key={n.id}
                className="card"
                style={{
                  margin: 0,
                  border: n.readFlag ? undefined : "1px solid var(--primary)",
                }}
              >
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    gap: "12px",
                    alignItems: "flex-start",
                  }}
                >
                  <div>
                    <div style={{ fontWeight: 700 }}>{n.title}</div>
                    <div style={{ color: "var(--gray)", fontSize: "14px" }}>
                      {n.message}
                    </div>
                    <div
                      style={{
                        color: "var(--gray)",
                        fontSize: "12px",
                        marginTop: "6px",
                      }}
                    >
                      {n.createdAt
                        ? new Date(n.createdAt).toLocaleString()
                        : ""}
                    </div>
                  </div>

                  {!n.readFlag && (
                    <button
                      className="btn btn-sm btn-outline"
                      onClick={() => markRead(n.id)}
                    >
                      Mark read
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );
}
