import React, { useEffect, useState } from "react";
import { apiFetch } from "../../api/http.js";
import { subscribeTopic } from "../../api/ws.js";
import { useAuth } from "../../state/AuthContext.jsx";

function badgeForTicketStatus(status) {
  if (status === "RESOLVED" || status === "CLOSED")
    return "badge badge-success";
  if (status === "IN_PROGRESS") return "badge badge-warning";
  return "badge badge-primary";
}

function badgeForPriority(priority) {
  if (priority === "HIGH") return "badge badge-danger";
  if (priority === "LOW") return "badge badge-primary";
  return "badge badge-warning";
}

export default function UserSupportPage() {
  const auth = useAuth();
  const [subject, setSubject] = useState("");
  const [description, setDescription] = useState("");
  const [priority, setPriority] = useState("MEDIUM");

  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const data = await apiFetch("/api/support/tickets/mine?page=0&size=50");
      setItems(data.content || []);
    } catch (e) {
      setError(e?.message || "Failed to load tickets");
      setItems([]);
    } finally {
      setLoading(false);
    }
  }

  async function submit(e) {
    e.preventDefault();
    setSubmitting(true);
    try {
      await apiFetch("/api/support/tickets", {
        method: "POST",
        body: JSON.stringify({ subject, description, priority }),
      });
      setSubject("");
      setDescription("");
      setPriority("MEDIUM");
      await load();
    } catch (e2) {
      alert(e2?.message || "Failed to raise ticket");
    } finally {
      setSubmitting(false);
    }
  }

  useEffect(() => {
    load();
    if (!auth.user?.id) return;
    let unsub = null;
    subscribeTopic(`/topic/tickets.user.${auth.user.id}`, () => {
      load();
    })
      .then((u) => {
        unsub = u;
      })
      .catch(() => {});

    return () => {
      if (unsub) unsub();
    };
  }, []);

  return (
    <>
      <div className="dashboard-header">
        <h1 className="dashboard-title">Support</h1>
      </div>

      <div className="card" style={{ marginBottom: "30px" }}>
        <h3 style={{ marginBottom: "20px" }}>Raise Support Ticket</h3>
        <form onSubmit={submit}>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: "20px",
              marginBottom: "20px",
            }}
          >
            <div className="form-group" style={{ marginBottom: 0 }}>
              <label className="form-label">Subject</label>
              <input
                className="form-input"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                required
              />
            </div>
            <div className="form-group" style={{ marginBottom: 0 }}>
              <label className="form-label">Priority</label>
              <select
                className="form-select"
                value={priority}
                onChange={(e) => setPriority(e.target.value)}
              >
                <option value="LOW">LOW</option>
                <option value="MEDIUM">MEDIUM</option>
                <option value="HIGH">HIGH</option>
              </select>
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">Description</label>
            <textarea
              className="form-textarea"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={4}
              required
            />
          </div>
          <div style={{ display: "flex", gap: "12px" }}>
            <button
              className="btn btn-primary"
              type="submit"
              disabled={submitting}
            >
              <i className="fas fa-plus"></i>{" "}
              {submitting ? "Submitting..." : "Submit Ticket"}
            </button>
            <button
              className="btn btn-outline"
              type="button"
              onClick={load}
              disabled={loading}
            >
              <i className="fas fa-sync-alt"></i> Refresh
            </button>
          </div>
        </form>
      </div>

      <div className="card">
        <h3 style={{ marginBottom: "20px" }}>Your Support Tickets</h3>

        <div className="table-container" style={{ boxShadow: "none" }}>
          {error && (
            <div className="error" style={{ padding: "20px" }}>
              {error}
            </div>
          )}

          {loading ? (
            <div className="loading">Loading tickets...</div>
          ) : items.length === 0 ? (
            <div className="empty">No tickets submitted yet.</div>
          ) : (
            <table className="table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Subject</th>
                  <th>Priority</th>
                  <th>Status</th>
                  <th>Created</th>
                </tr>
              </thead>
              <tbody>
                {items.map((t) => (
                  <tr key={t.id}>
                    <td>#{t.id}</td>
                    <td>{t.subject}</td>
                    <td>
                      <span className={badgeForPriority(t.priority)}>
                        {t.priority}
                      </span>
                    </td>
                    <td>
                      <span className={badgeForTicketStatus(t.status)}>
                        {t.status}
                      </span>
                    </td>
                    <td>
                      {t.createdAt
                        ? new Date(t.createdAt).toLocaleDateString()
                        : "-"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </>
  );
}
