import React from "react";
import {
  NavLink,
  Route,
  Routes,
  Navigate,
  useLocation,
} from "react-router-dom";
import { useAuth } from "../state/AuthContext.jsx";
import UserBookingsPage from "./dash/UserBookingsPage.jsx";
import UserSupportPage from "./dash/UserSupportPage.jsx";
import UserBookFormPage from "./dash/UserBookFormPage.jsx";
import SupportQueuePage from "./dash/SupportQueuePage.jsx";
import ProfessionalBookingsPage from "./dash/ProfessionalBookingsPage.jsx";
import NotificationsPage from "./dash/NotificationsPage.jsx";

function SidebarLink({ to, icon, label }) {
  return (
    <li className="sidebar-item">
      <NavLink
        to={to}
        className={({ isActive }) => `sidebar-link ${isActive ? "active" : ""}`}
      >
        <i className={`fas ${icon}`}></i> {label}
      </NavLink>
    </li>
  );
}

export default function DashboardPage() {
  const auth = useAuth();
  const location = useLocation();
  const role = auth.user?.role;

  return (
    <div className="dashboard">
      <aside className="dashboard-sidebar">
        <ul className="sidebar-menu">
          <SidebarLink
            to="/dashboard/notifications"
            icon="fa-bell"
            label="Notifications"
          />

          {role === "user" && (
            <>
              <SidebarLink
                to="/dashboard/bookings"
                icon="fa-calendar"
                label="My Bookings"
              />
              <SidebarLink
                to="/dashboard/support"
                icon="fa-life-ring"
                label="Support"
              />
            </>
          )}

          {role === "support" && (
            <>
              <SidebarLink
                to="/dashboard/tickets"
                icon="fa-ticket-alt"
                label="Ticket Queue"
              />
            </>
          )}

          {role === "admin" && (
            <>
              <SidebarLink
                to="/dashboard/tickets"
                icon="fa-ticket-alt"
                label="Support Tickets"
              />
            </>
          )}

          {role === "professional" && (
            <>
              <SidebarLink
                to="/dashboard/pro-bookings"
                icon="fa-calendar"
                label="Bookings"
              />
            </>
          )}
        </ul>
      </aside>

      <main className="dashboard-content">
        <Routes>
          <Route
            path="/"
            element={
              role === "user" ? (
                <Navigate to="/dashboard/bookings" replace />
              ) : role === "professional" ? (
                <Navigate to="/dashboard/pro-bookings" replace />
              ) : (
                <Navigate to="/dashboard/tickets" replace />
              )
            }
          />

          <Route path="book" element={<UserBookFormPage />} />
          <Route path="bookings" element={<UserBookingsPage />} />
          <Route path="support" element={<UserSupportPage />} />
          <Route path="tickets" element={<SupportQueuePage />} />
          <Route path="notifications" element={<NotificationsPage />} />
          <Route path="pro-bookings" element={<ProfessionalBookingsPage />} />
          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </main>
    </div>
  );
}
