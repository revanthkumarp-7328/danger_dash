import React, { useEffect, useState } from "react";
import { apiFetch } from "../api/http.js";
import { useAuth } from "../state/AuthContext.jsx";
import { useNavigate } from "react-router-dom";

export default function HomePage() {
  const auth = useAuth();
  const navigate = useNavigate();

  const [categories, setCategories] = useState([]);
  const [professionals, setProfessionals] = useState([]);
  const [services, setServices] = useState([]);
  const [initLoading, setInitLoading] = useState(true);
  const [initError, setInitError] = useState(null);
  const [query, setQuery] = useState("");
  const [categoryName, setCategoryName] = useState("");
  const [selectedCategoryId, setSelectedCategoryId] = useState(null);
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);

  function scrollToSection(id) {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  }

  async function loadInit() {
    setInitLoading(true);
    setInitError(null);
    try {
      const [catData, profData, svcData] = await Promise.all([
        apiFetch("/api/public/service-categories"),
        apiFetch("/api/public/search?page=0&size=6").then(
          (d) => d.content || [],
        ),
        apiFetch("/api/public/search?page=0&size=6").then(
          (d) => d.content || [],
        ),
      ]);
      setCategories(catData || []);
      setProfessionals(profData.slice(0, 6));
      setServices(svcData.slice(0, 6));
    } catch (e) {
      setInitError(e?.message || "Failed to load data");
      setCategories([]);
      setProfessionals([]);
      setServices([]);
    } finally {
      setInitLoading(false);
    }
  }

  useEffect(() => {
    loadInit();
  }, []);

  async function search() {
    setLoading(true);
    try {
      const url = new URL(window.location.origin + "/api/public/search");
      if (query) url.searchParams.set("city", query);
      if (selectedCategoryId)
        url.searchParams.set("categoryId", String(selectedCategoryId));
      const data = await apiFetch(url.pathname + url.search);
      setResults(data.content || []);
      setTimeout(() => {
        document
          .getElementById("search-results")
          ?.scrollIntoView({ behavior: "smooth" });
      }, 0);
    } catch {
      setResults([]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      {/* Hero */}
      <section className="hero">
        <div className="container">
          <div className="hero-content">
            <h1 className="hero-title">Find & Hire the Right Professional</h1>
            <p className="hero-subtitle">
              Connect with verified experts across all industries. Get quality
              service from professionals you can trust.
            </p>
            <div className="hero-search">
              <input
                type="text"
                placeholder="What service do you need?"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
              <select
                value={categoryName}
                onChange={(e) => setCategoryName(e.target.value)}
              >
                <option value="">All Categories</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>
              <button
                className="btn btn-primary btn-lg"
                onClick={search}
                disabled={loading}
              >
                <i className="fas fa-search"></i> Search
              </button>
            </div>
            <div className="hero-stats">
              <div className="hero-stat">
                <div className="hero-stat-number">10,000+</div>
                <div className="hero-stat-label">Professionals</div>
              </div>
              <div className="hero-stat">
                <div className="hero-stat-number">50,000+</div>
                <div className="hero-stat-label">Services</div>
              </div>
              <div className="hero-stat">
                <div className="hero-stat-number">100,000+</div>
                <div className="hero-stat-label">Happy Clients</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Search Results */}
      {results.length > 0 && (
        <section
          className="section"
          id="search-results"
          style={{ background: "var(--gray-100)" }}
        >
          <div className="container">
            <div className="section-header">
              <h2 className="section-title">Search Results</h2>
              <p className="section-subtitle">
                Found {results.length} professionals
              </p>
            </div>
            <div className="professionals-grid">
              {results.map((p) => (
                <div
                  key={p.professionalServiceId}
                  className="professional-card"
                >
                  <div className="professional-header">
                    <img
                      src={`https://randomuser.me/api/portraits/men/${p.professionalServiceId % 100}.jpg`}
                      alt={p.professionalName}
                      className="professional-image"
                    />
                    <h3 className="professional-name">{p.professionalName}</h3>
                    <p className="professional-title">{p.serviceTypeName}</p>
                  </div>
                  <div className="professional-body">
                    <div className="professional-rating">
                      <i className="fas fa-star"></i>
                      <span>{(p.rating || 4.5).toFixed(1)}</span>
                      <small>({p.reviewCount || 24} reviews)</small>
                    </div>
                    <span className="professional-category">
                      {p.serviceCategory}
                    </span>
                    <div className="professional-footer">
                      <div className="professional-price">
                        ${p.price}
                        <small>/{p.priceUnit}</small>
                      </div>
                      {auth.isAuthed && auth.user?.role === "user" ? (
                        <button
                          className="btn btn-primary btn-sm"
                          onClick={() =>
                            navigate(
                              `/dashboard/book?serviceId=${p.professionalServiceId}`,
                            )
                          }
                        >
                          Book
                        </button>
                      ) : (
                        <button
                          className="btn btn-sm btn-outline"
                          onClick={() => navigate("/login")}
                        >
                          Login
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Categories */}
      <section className="section" id="categories">
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">Browse by Category</h2>
            <p className="section-subtitle">
              Find professionals in your area of need
            </p>
          </div>
          <div className="categories-grid">
            {initLoading ? (
              <div className="empty" style={{ gridColumn: "1 / -1" }}>
                Loading categories...
              </div>
            ) : initError ? (
              <div className="empty" style={{ gridColumn: "1 / -1" }}>
                {initError}{" "}
                <button className="btn btn-outline" onClick={loadInit}>
                  Retry
                </button>
              </div>
            ) : categories.length === 0 ? (
              <div className="empty" style={{ gridColumn: "1 / -1" }}>
                No categories found.
              </div>
            ) : (
              categories.map((c) => (
                <div
                  key={c.id}
                  className="category-card"
                  onClick={() => {
                    setCategoryName(c.name);
                    setSelectedCategoryId(c.id);
                    search();
                  }}
                >
                  <div className="category-icon">
                    <i className="fas fa-briefcase"></i>
                  </div>
                  <div className="category-name">{c.name}</div>
                </div>
              ))
            )}
          </div>
        </div>
      </section>

      {/* Professionals */}
      <section
        className="section"
        id="professionals"
        style={{ background: "var(--gray-100)" }}
      >
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">Top Rated Professionals</h2>
            <p className="section-subtitle">
              Discover highly-rated experts ready to help
            </p>
          </div>
          <div className="professionals-grid">
            {initLoading ? (
              <div className="empty" style={{ gridColumn: "1 / -1" }}>
                Loading professionals...
              </div>
            ) : initError ? (
              <div className="empty" style={{ gridColumn: "1 / -1" }}>
                {initError}{" "}
                <button className="btn btn-outline" onClick={loadInit}>
                  Retry
                </button>
              </div>
            ) : professionals.length === 0 ? (
              <div className="empty" style={{ gridColumn: "1 / -1" }}>
                No professionals found.
              </div>
            ) : (
              professionals.map((p) => (
                <div
                  key={p.professionalServiceId}
                  className="professional-card"
                >
                  <div className="professional-header">
                    {p.verified && (
                      <span className="verified-badge">
                        <i className="fas fa-check"></i> Verified
                      </span>
                    )}
                    <img
                      src={`https://randomuser.me/api/portraits/men/${p.professionalServiceId % 100}.jpg`}
                      alt={p.professionalName}
                      className="professional-image"
                    />
                    <h3 className="professional-name">{p.professionalName}</h3>
                    <p className="professional-title">{p.serviceTypeName}</p>
                  </div>
                  <div className="professional-body">
                    <div className="professional-rating">
                      <i className="fas fa-star"></i>
                      <span>{(p.rating || 4.5).toFixed(1)}</span>
                      <small>({p.reviewCount || 24} reviews)</small>
                    </div>
                    <span className="professional-category">
                      {p.serviceCategory}
                    </span>
                    <p className="professional-bio">
                      {p.bio ||
                        "Experienced professional ready to help you with your needs."}
                    </p>
                    <div className="professional-footer">
                      <div className="professional-price">
                        ${p.price}
                        <small>/{p.priceUnit}</small>
                      </div>
                      <button
                        className="btn btn-primary btn-sm"
                        onClick={() =>
                          navigate(
                            auth.isAuthed
                              ? `/dashboard/book?serviceId=${p.professionalServiceId}`
                              : "/login",
                          )
                        }
                      >
                        View Profile
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="section" id="services">
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">Popular Services</h2>
            <p className="section-subtitle">
              Browse our most requested services
            </p>
          </div>
          <div className="services-grid">
            {initLoading ? (
              <div className="empty" style={{ gridColumn: "1 / -1" }}>
                Loading services...
              </div>
            ) : initError ? (
              <div className="empty" style={{ gridColumn: "1 / -1" }}>
                {initError}{" "}
                <button className="btn btn-outline" onClick={loadInit}>
                  Retry
                </button>
              </div>
            ) : services.length === 0 ? (
              <div className="empty" style={{ gridColumn: "1 / -1" }}>
                No services found.
              </div>
            ) : (
              services.map((s) => (
                <div key={s.professionalServiceId} className="service-card">
                  <div className="service-header">
                    <h4 className="service-title">{s.serviceTypeName}</h4>
                    <span className="service-category">
                      {s.serviceCategory}
                    </span>
                  </div>
                  <div className="service-body">
                    <p className="service-description">
                      {s.bio || "Professional service with quality guaranteed."}
                    </p>
                    <div className="service-meta">
                      <div className="service-meta-item">
                        <i className="fas fa-clock"></i>
                        <span>2-3 hours</span>
                      </div>
                      <div className="service-meta-item">
                        <i className="fas fa-star"></i>
                        <span>{(s.rating || 4.5).toFixed(1)}</span>
                      </div>
                    </div>
                    <div className="service-footer">
                      <span className="service-price">${s.price}</span>
                      <button
                        className="btn btn-sm btn-outline"
                        onClick={() =>
                          navigate(
                            auth.isAuthed
                              ? `/dashboard/book?serviceId=${s.professionalServiceId}`
                              : "/login",
                          )
                        }
                      >
                        Book Now
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section
        className="section"
        id="how-it-works"
        style={{ background: "var(--gray-100)" }}
      >
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">How It Works</h2>
            <p className="section-subtitle">
              Get the help you need in 4 simple steps
            </p>
          </div>
          <div className="steps-grid">
            <div className="step-card">
              <div className="step-number">1</div>
              <h3 className="step-title">Search</h3>
              <p className="step-description">
                Browse professionals by category or search for specific services
              </p>
            </div>
            <div className="step-card">
              <div className="step-number">2</div>
              <h3 className="step-title">Compare</h3>
              <p className="step-description">
                Review profiles, ratings, and prices to find the right match
              </p>
            </div>
            <div className="step-card">
              <div className="step-number">3</div>
              <h3 className="step-title">Hire</h3>
              <p className="step-description">
                Book the professional and schedule your service
              </p>
            </div>
            <div className="step-card">
              <div className="step-number">4</div>
              <h3 className="step-title">Review</h3>
              <p className="step-description">
                Get quality service and share your experience
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="cta">
        <div className="container">
          <h2 className="cta-title">Ready to Get Started?</h2>
          <p className="cta-subtitle">
            Join thousands of satisfied customers and professionals on
            ProConnect
          </p>
          <button
            className="btn btn-secondary btn-lg"
            onClick={() => navigate("/register")}
          >
            <i className="fas fa-user-plus"></i> Join Now - It's Free
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="footer">
        <div className="container">
          <div className="footer-grid">
            <div>
              <div className="footer-brand">ProConnect</div>
              <p className="footer-description">
                Connecting you with verified professionals for all your service
                needs.
              </p>
              <div className="footer-social">
                <a
                  href="https://www.facebook.com"
                  target="_blank"
                  rel="noreferrer"
                >
                  <i className="fab fa-facebook-f"></i>
                </a>
                <a
                  href="https://www.twitter.com"
                  target="_blank"
                  rel="noreferrer"
                >
                  <i className="fab fa-twitter"></i>
                </a>
                <a
                  href="https://www.linkedin.com"
                  target="_blank"
                  rel="noreferrer"
                >
                  <i className="fab fa-linkedin-in"></i>
                </a>
                <a
                  href="https://www.instagram.com"
                  target="_blank"
                  rel="noreferrer"
                >
                  <i className="fab fa-instagram"></i>
                </a>
              </div>
            </div>
            <div>
              <h4 className="footer-title">For Clients</h4>
              <ul className="footer-links">
                <li>
                  <a
                    href="#how-it-works"
                    onClick={(e) => {
                      e.preventDefault();
                      scrollToSection("how-it-works");
                    }}
                  >
                    How to Hire
                  </a>
                </li>
                <li>
                  <a
                    href="#professionals"
                    onClick={(e) => {
                      e.preventDefault();
                      scrollToSection("professionals");
                    }}
                  >
                    Browse Professionals
                  </a>
                </li>
                <li>
                  <a
                    href="/register"
                    onClick={(e) => {
                      e.preventDefault();
                      navigate("/register");
                    }}
                  >
                    Payment Protection
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="footer-title">For Professionals</h4>
              <ul className="footer-links">
                <li>
                  <a
                    href="/register"
                    onClick={(e) => {
                      e.preventDefault();
                      navigate("/register");
                    }}
                  >
                    How to Join
                  </a>
                </li>
                <li>
                  <a
                    href="#professionals"
                    onClick={(e) => {
                      e.preventDefault();
                      scrollToSection("professionals");
                    }}
                  >
                    Success Stories
                  </a>
                </li>
                <li>
                  <a
                    href="#services"
                    onClick={(e) => {
                      e.preventDefault();
                      scrollToSection("services");
                    }}
                  >
                    Resources
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="footer-title">Support</h4>
              <ul className="footer-links">
                <li>
                  <a
                    href={auth.isAuthed ? "/dashboard/support" : "/login"}
                    onClick={(e) => {
                      e.preventDefault();
                      navigate(auth.isAuthed ? "/dashboard/support" : "/login");
                    }}
                  >
                    Help Center
                  </a>
                </li>
                <li>
                  <a href="mailto:support@proconnect.com">Contact Us</a>
                </li>
                <li>
                  <a
                    href="/terms"
                    onClick={(e) => {
                      e.preventDefault();
                      navigate("/terms");
                    }}
                  >
                    Terms of Service
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="footer-bottom">
            <p>&copy; 2024 ProConnect. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </>
  );
}
