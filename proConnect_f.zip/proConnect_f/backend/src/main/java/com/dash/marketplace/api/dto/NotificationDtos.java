package com.dash.marketplace.api.dto;

import jakarta.validation.constraints.NotNull;

public class NotificationDtos {

    public record MarkReadRequest(@NotNull Long notificationId) {}
}
