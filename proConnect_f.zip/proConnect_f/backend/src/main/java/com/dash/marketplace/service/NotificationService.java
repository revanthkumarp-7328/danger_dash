package com.dash.marketplace.service;

import com.dash.marketplace.domain.Notification;
import com.dash.marketplace.domain.User;
import com.dash.marketplace.repo.NotificationRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class NotificationService {

    private final NotificationRepository notificationRepository;
    private final SimpMessagingTemplate messagingTemplate;

    public NotificationService(NotificationRepository notificationRepository,
                               SimpMessagingTemplate messagingTemplate) {
        this.notificationRepository = notificationRepository;
        this.messagingTemplate = messagingTemplate;
    }

    @Transactional
    public Notification notify(User recipient, String type, String title, String message) {
        Notification saved = notificationRepository.save(new Notification(recipient, type, title, message));
        messagingTemplate.convertAndSend("/topic/notifications." + recipient.getId(), saved);
        return saved;
    }

    public Page<Notification> myNotifications(Long userId, Pageable pageable) {
        return notificationRepository.findByRecipientIdOrderByCreatedAtDesc(userId, pageable);
    }

    public long unreadCount(Long userId) {
        return notificationRepository.countByRecipientIdAndReadFlagFalse(userId);
    }

    @Transactional
    public void markRead(Long notificationId, Long userId) {
        Notification n = notificationRepository.findById(notificationId)
                .orElseThrow(() -> new IllegalArgumentException("Notification not found"));
        if (!n.getRecipient().getId().equals(userId)) {
            throw new IllegalArgumentException("Not your notification");
        }
        n.setReadFlag(true);
    }
}
