package com.dash.marketplace.repo;

import com.dash.marketplace.domain.ProfessionalService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ProfessionalServiceRepository extends JpaRepository<ProfessionalService, Long> {

    List<ProfessionalService> findByProfileId(Long profileId);

    @Query("""
        select ps from ProfessionalService ps
        join ps.profile p
        join p.user u
        join ps.serviceType st
        join st.category cat
        where ps.active = true
          and p.verificationStatus = com.dash.marketplace.domain.VerificationStatus.APPROVED
          and (:serviceTypeId is null or ps.serviceType.id = :serviceTypeId)
          and (:categoryId is null or cat.id = :categoryId)
          and (:city is null or lower(p.locationCity) like lower(concat('%', :city, '%')))
          and (:minRating is null or p.avgRating >= :minRating)
          and (:priceMin is null or ps.basePrice >= :priceMin)
          and (:priceMax is null or ps.basePrice <= :priceMax)
    """)
    Page<ProfessionalService> search(
            @Param("serviceTypeId") Long serviceTypeId,
            @Param("categoryId") Long categoryId,
            @Param("city") String city,
            @Param("minRating") Double minRating,
            @Param("priceMin") Double priceMin,
            @Param("priceMax") Double priceMax,
            Pageable pageable
    );
}
