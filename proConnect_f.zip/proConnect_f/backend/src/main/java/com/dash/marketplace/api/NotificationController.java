package com.dash.marketplace.api;

import com.dash.marketplace.api.dto.NotificationDtos;
import com.dash.marketplace.domain.Notification;
import com.dash.marketplace.service.CurrentUserService;
import com.dash.marketplace.service.NotificationService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {

    private final CurrentUserService currentUserService;
    private final NotificationService notificationService;

    public NotificationController(CurrentUserService currentUserService, NotificationService notificationService) {
        this.currentUserService = currentUserService;
        this.notificationService = notificationService;
    }

    @GetMapping
    public Page<Notification> myNotifications(@RequestParam(defaultValue = "0") int page,
                                             @RequestParam(defaultValue = "20") int size) {
        Long userId = currentUserService.requireUserId();
        return notificationService.myNotifications(userId, PageRequest.of(page, size));
    }

    @GetMapping("/unread-count")
    public long unreadCount() {
        Long userId = currentUserService.requireUserId();
        return notificationService.unreadCount(userId);
    }

    @PostMapping("/mark-read")
    public void markRead(@Valid @RequestBody NotificationDtos.MarkReadRequest req) {
        Long userId = currentUserService.requireUserId();
        notificationService.markRead(req.notificationId(), userId);
    }
}
