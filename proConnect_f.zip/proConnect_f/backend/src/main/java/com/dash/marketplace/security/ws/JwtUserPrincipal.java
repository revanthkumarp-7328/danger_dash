package com.dash.marketplace.security.ws;

import java.security.Principal;

public class JwtUserPrincipal implements Principal {

    private final String name;

    public JwtUserPrincipal(String name) {
        this.name = name;
    }

    @Override
    public String getName() {
        return name;
    }
}
