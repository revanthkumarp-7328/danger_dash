package com.dash.marketplace.service;

import com.dash.marketplace.api.dto.PublicDtos;
import com.dash.marketplace.domain.ProfessionalService;
import com.dash.marketplace.repo.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.ZoneId;
import java.util.List;

@Service
public class PublicService {

    private final ServiceCategoryRepository serviceCategoryRepository;
    private final ServiceTypeRepository serviceTypeRepository;
    private final ProfessionalServiceRepository professionalServiceRepository;
    private final ProfessionalProfileRepository professionalProfileRepository;
    private final ReviewRepository reviewRepository;

    public PublicService(ServiceCategoryRepository serviceCategoryRepository,
                         ServiceTypeRepository serviceTypeRepository,
                         ProfessionalServiceRepository professionalServiceRepository,
                         ProfessionalProfileRepository professionalProfileRepository,
                         ReviewRepository reviewRepository) {
        this.serviceCategoryRepository = serviceCategoryRepository;
        this.serviceTypeRepository = serviceTypeRepository;
        this.professionalServiceRepository = professionalServiceRepository;
        this.professionalProfileRepository = professionalProfileRepository;
        this.reviewRepository = reviewRepository;
    }

    public List<PublicDtos.ServiceCategoryDto> categories() {
        return serviceCategoryRepository.findAll().stream()
                .map(c -> new PublicDtos.ServiceCategoryDto(c.getId(), c.getName()))
                .toList();
    }

    public List<PublicDtos.ServiceTypeDto> serviceTypes(Long categoryId) {
        return serviceTypeRepository.findByCategoryId(categoryId).stream()
                .map(st -> new PublicDtos.ServiceTypeDto(st.getId(), st.getCategory().getId(), st.getName()))
                .toList();
    }

    public Page<PublicDtos.ProfessionalServiceCardDto> search(Long serviceTypeId, Long categoryId, String city, Double minRating, Double priceMin, Double priceMax, Pageable pageable) {
        Page<ProfessionalService> page = professionalServiceRepository.search(serviceTypeId, categoryId, city, minRating, priceMin, priceMax, pageable);
        return page.map(ps -> new PublicDtos.ProfessionalServiceCardDto(
                ps.getId(),
                ps.getProfile().getId(),
                ps.getServiceType().getId(),
                ps.getServiceType().getName(),
                ps.getTitle(),
                ps.getDescription(),
                ps.getBasePrice(),
                ps.getPriceUnit().name(),
                ps.getProfile().getUser().getFullName(),
                ps.getProfile().getLocationCity(),
                ps.getProfile().getAvgRating(),
                ps.getProfile().getTotalReviews()
        ));
    }

    public PublicDtos.ProfessionalProfileDto profile(Long profileId) {
        var profile = professionalProfileRepository.findById(profileId).orElseThrow(() -> new IllegalArgumentException("Profile not found"));
        var services = professionalServiceRepository.findByProfileId(profileId).stream()
                .filter(ProfessionalService::isActive)
                .map(ps -> new PublicDtos.ProfessionalServiceCardDto(
                        ps.getId(),
                        profile.getId(),
                        ps.getServiceType().getId(),
                        ps.getServiceType().getName(),
                        ps.getTitle(),
                        ps.getDescription(),
                        ps.getBasePrice(),
                        ps.getPriceUnit().name(),
                        profile.getUser().getFullName(),
                        profile.getLocationCity(),
                        profile.getAvgRating(),
                        profile.getTotalReviews()
                ))
                .toList();

        var reviews = reviewRepository.findByProfessionalIdOrderByCreatedAtDesc(profileId).stream()
                .map(r -> new PublicDtos.ReviewDto(
                        r.getId(),
                        r.getBooking().getId(),
                        r.getRating(),
                        r.getComment(),
                        r.getCreatedAt().atZone(ZoneId.systemDefault()).toOffsetDateTime().toString()
                ))
                .toList();

        return new PublicDtos.ProfessionalProfileDto(
                profile.getId(),
                profile.getUser().getId(),
                profile.getUser().getFullName(),
                profile.getHeadline(),
                profile.getBio(),
                profile.getLocationCity(),
                profile.getLocationArea(),
                profile.getYearsExperience(),
                profile.getAvgRating(),
                profile.getTotalReviews(),
                services,
                reviews
        );
    }
}
