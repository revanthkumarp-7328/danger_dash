package com.dash.marketplace.repo;

import com.dash.marketplace.domain.RoleName;
import com.dash.marketplace.domain.User;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);

    @Query("select distinct u from User u join u.roles r where r.name = :role")
    List<User> findAllByRole(@Param("role") RoleName role);
}
